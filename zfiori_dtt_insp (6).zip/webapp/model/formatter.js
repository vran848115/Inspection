sap.ui.define([], function () {
	"use strict";
	return {
		keyData: function (aKeys) {
			if (aKeys.length > 0) {
				return aKeys.toString();
			}
			return "";
		}
	};
});