sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/ui/model/type/String',
	"sap/m/MessageBox",
	'sap/m/Label',
	'sap/m/SearchField', 'sap/m/Token',
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/model/odata/v2/ODataModel',
	'sap/ui/table/Column',
	'sap/m/Column',
	'sap/m/Text',
	"com/gascozgasco/model/formatter"
], function (Controller, JSONModel, typeString, MessageBox, SearchField, Token, Filter, FilterOperator, ODataModel, UIColumn, MColumn,
	Text, formatter) {
	"use strict";

	return Controller.extend("com.gascozgasco.controller.Main", {
		formatter: formatter,
		onInit: function () {
			this._oBusyDialog = new sap.m.BusyDialog;
			var oRouter = this.getRouter();
			oRouter.getRoute("Main").attachPatternMatched(this._onObjectMatched, this);

		},
		_onObjectMatched: function (oEvent) {

			//oEvent.getParameter("arguments").invoicePath
			if (oEvent.getParameter("arguments").InspId) {
				this.getView().setModel(new JSONModel(), 'data');
				this.sInp = oEvent.getParameter("arguments").InspId;

				this.getView().getModel('data').setProperty('/previousEnabled', false)
				this.getView().getModel('data').setProperty('/nextEnabled', false)
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/closeVisible', false)
				this.getView().getModel('data').setProperty('/continueEnabled', true)
				this.oResourceBundle = this.getOwnerComponent().getModel('i18n').getResourceBundle();
				this._oWizard = this.byId("CreateProductWizard");
				this._iSelectedStepIndex = 0;
				this.bValidated = true;
				this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex];
				//Set View Data
				//this.setViewData();
				this._oWizard.attachModelContextChange((oEvent) => {
					// debugger
				});
				this._oWizard.attachValidationSuccess((oEvent) => {
					// debugger
				});
				this.getInitLoad();
			} else {
				//	this.getInitLoad();
				this.sInp = "";
				this.getView().setModel(new JSONModel(), 'data')
				this.getView().getModel("data").setProperty("/ObjSelectedType", "FLEET_TK");
				this.getView().getModel('data').setProperty('/previousEnabled', false)
				this.getView().getModel('data').setProperty('/nextEnabled', false)
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/closeVisible', false)
				this.getView().getModel('data').setProperty('/continueEnabled', true)
				this.getView().getModel("data").setProperty("/InspNo", "");
				this.getView().byId("idPlant").setSelectedKey("");
				this.getView().byId('idCC').setSelectedKey("");
				this.getView().byId("idLoc").setSelectedKey("");
				this.getView().byId("iDInspType").setSelectedKey("");
				this.getView().byId("iDobjType").setSelectedKey("");
				// this.getView().byId("SubObjId").setSelectedKey("");
				this.getView().getModel("data").setProperty("/DriverId", "");
				this.getView().getModel("data").setProperty("/DriverName", "");
				this.getView().byId("idTruckId").setValue("");
				this.getView().byId("idTankId").setValue("");
				this.getView().byId("idTruckMil").setValue("");
				this.oResourceBundle = this.getOwnerComponent().getModel('i18n').getResourceBundle();
				this._oWizard = this.byId("CreateProductWizard");
				this._iSelectedStepIndex = 0;
				this.bValidated = true;
				this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex];
				this.getInitLoad();
				//Set View Data
				//this.setViewData();
				this._oWizard.attachModelContextChange((oEvent) => {
					// debugger
				});
				this._oWizard.attachValidationSuccess((oEvent) => {
					// debugger
				});
				this._oWizard.setCurrentStep(this._oSelectedStep);
				this._oWizard.goToStep(this._oSelectedStep, true);

			}
			this.getView().getModel("data").setProperty("/editVisible", false);
			this.getView().getModel("data").setProperty("/displyVisible", false);

		},
		getInspectData: function (sInpId) {
			this.oModel = this.getOwnerComponent().getModel();
			var that = this;
			this.oModel.read("/ET_Checklist_Hdr_PostSet", {
				filters: [new sap.ui.model.Filter("InspId", "EQ", sInpId)],
				urlParameters: {
					$expand: "NAVCHLPOST,NAVTYRESDATA"
				},
				success: function (oData) {
					if (oData.results.length > 0) {
						this.oStatus = oData.results[0].Status;
						this.getView().getModel("data").setProperty("/editVisible", true);
						this.getView().getModel("data").setProperty("/InspNo", oData.results[0].InspId);
						that.getView().getModel('data').setProperty('/pNotif', oData.results[0].PNotif);
						that.getView().getModel('data').setProperty('/cNotif', oData.results[0].CNotif);
						this.getView().byId("idPlant").setSelectedKey(oData.results[0].MaintPlant);
						this.getView().byId('idCC').setSelectedKey(oData.results[0].CostCenter);
						this.getView().byId("idLoc").setSelectedKey(oData.results[0].InspLoc);
						this.getView().byId("iDInspType").setSelectedKey(oData.results[0].InspType);
						this.getView().byId("iDobjType").setSelectedKey(oData.results[0].ObjectType);
						// this.getView().byId("SubObjId").setSelectedKey(oData.results[0].SubObjectType);
						this.getView().getModel("data").setProperty("/DriverId", oData.results[0].DriverId);
						this.getView().getModel("data").setProperty("/DriverName", oData.results[0].DriverName);
						this.getView().byId("idTruckId").setValue(oData.results[0].PEquipment);
						this.getView().byId("idTankId").setValue(oData.results[0].CEquipment);
						// Tanker Tire based on Old and New tanker
						var tankNo = oData.results[0].CEquipment;
						var tankTh = "TN-0900";
						const tCompare = tankNo.localeCompare(tankTh);
						// 1 if tankNo is greater (higher in the alphabetical order) than tankTh => NEW
						// -1 if tankNo is smaller (lower in the alphabetical order) than tankTh => OLD Model 8 Tires
						// 0 if tankTh and tankTh are equal in the alphabetical order => NEW Model 6 tires
						if (tCompare >= 0) {
							this.getView().byId("idTank7").setVisible(false);
							this.getView().byId("idTank7Image").setVisible(false);
							this.getView().byId("idTank8Image").setVisible(false);
							this.getView().byId("idTank8").setVisible(false);
							this.getView().byId("idTankMiddle2").setVisible(true);
							this.getView().byId("idTankMiddle1").setVisible(false);
							this.getView().byId("idTankLast1").setVisible(true);
							this.getView().byId("idTankLast2").setVisible(false);

						} else if (tCompare === -1) {
							this.getView().byId("idTankLast2").setVisible(true);
							this.getView().byId("idTankLast1").setVisible(false);
							this.getView().byId("idTank7").setVisible(true);
							this.getView().byId("idTank7Image").setVisible(true);
							this.getView().byId("idTank8Image").setVisible(true);
							this.getView().byId("idTank8").setVisible(true);
						}
						this.getView().byId("idTruckMil").setValue(oData.results[0].TruckMilage);
						//Read Inspection Summary
						this.oModel.read("/ES_INSP_SUMMARYSet", {
							filters: [new sap.ui.model.Filter("InspId", "EQ", oData.results[0].InspId)],
							success: function (oData) {
								this.getView().getModel('data').setProperty('/inspectionsummary', oData.results);
								this.getView().getModel('data').setProperty('/docpass', oData.results[0].DiPass);
								this.getView().getModel('data').setProperty('/iteration', oData.results[0].Iteration);
								this.getView().getModel('data').setProperty('/docfail', oData.results[0].DiFail);
								this.getView().getModel('data').setProperty('/truckpass', oData.results[0].TriPass);
								this.getView().getModel('data').setProperty('/truckfail', oData.results[0].TriFail);
								this.getView().getModel('data').setProperty('/tankerpass', oData.results[0].TniPass);
								this.getView().getModel('data').setProperty('/tankerfail', oData.results[0].TniFail);

							}.bind(this),
							error: function (oError) {
								sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}.bind(this),
						});
						//Read Inspection Attachments
						this.oModel.read("/ES_MEDIA_DATA", {
							filters: [new sap.ui.model.Filter("InspId", "EQ", oData.results[0].InspId)],
							success: function (oData) {
								var oTruckFiles = [];
								var oTankFiles = [];
								for (var i = 0; i < oData.results.length; i++) {
									switch (oData.results[i].ChlistCat) {
										// 01- Truck Inspection Checklist
										// 02-Tanker Inspection Checklist
										// 03-Flatbed Inspection Checklist
										// 04-Document Inspection Checklist
									case "01":
										oTruckFiles.push(oData.results[i]);
										break;
									case "02":
										oTankFiles.push(oData.results[i]);
										break;
									case "03":
										break;
									case "04":
										break;
									default:
									}
								}
								this.getView().getModel('data').setProperty('/truckFiles', oTruckFiles);
								this.getView().getModel('data').setProperty('/tankFiles', oTankFiles);
							}.bind(this),
							error: function (oError) {
								sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
							}.bind(this),
						});

						//Set Inspection checklist based on Object Type

						switch (oData.results[0].ObjectType) {
						case "FLEET_TK":
							var documentinspectionsArray = [];
							var documentinspections = this.getView().getModel("data").getProperty("/documentinspections");
							documentinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "04";
							});
							if (documentinspectionsArray.length > 0) {
								documentinspectionsArray.forEach(function (objDocArray, index) {
									documentinspections[index].slno = objDocArray.ChecklistNo
									documentinspections[index].description = objDocArray.ChecklistName
									documentinspections[index].bEditable = objDocArray.Pass === 'X' ? false : true;
									documentinspections[index].pass = objDocArray.Pass === 'X' ? true : false;
									documentinspections[index].fail = objDocArray.Pass === 'X' ? false : true;
									documentinspections[index].remarks = objDocArray.Remarks
								}.bind(this))

							}
							var truckinspectionsArray = [];
							var truckinspectionDuplicatesArray = [];
							truckinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "01" && objfilter.TaskCodeType.length > 0;
							});
							truckinspectionsArray.forEach(function (objTruck) {

								switch (objTruck.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var truckItem = this.getView().getModel("data").getProperty("/truckinspections")
									objTaskCode1 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTruck.Taskcode);
									objTaskCode1[0].remarks = objTruck.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var truckItem = this.getView().getModel("data").getProperty("/truckinspections");
									objTaskCode2 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTruck.Taskcode);
									objTaskCode2[0].remarks = objTruck.Remarks;
									objTaskCode2[0].fail = true;
									break;
								case "ELEC":
									var objTaskCode3 = [];
									var truckItem = this.getView().getModel("data").getProperty("/truckinspections")
									objTaskCode3 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTruck.Taskcode);
									objTaskCode3[0].remarks = objTruck.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var truckItem = this.getView().getModel("data").getProperty("/truckinspections")
									objTaskCode4 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTruck.Taskcode)
									objTaskCode4[0].remarks = objTruck.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var truckItem = this.getView().getModel("data").getProperty("/truckinspections");
							truckItem.forEach(function (objTruckItem) {
								if (!objTruckItem.pass && !objTruckItem.fail) {
									objTruckItem.pass = true
								}
							});
							var truckTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "01";
							});
							truckTyreData.forEach(function (truckTyreObj) {
								var arrTyreData = [];
								var truckTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = truckTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === truckTyreObj.TyreNo && tyreObj.ChecklistCat === "01";
								});
								arrTyreData[0].TreadDepth = truckTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = truckTyreObj.TyrePsi;

							}.bind(this));

							//======Tanker=======================
							var tankerinspectionsArray = [];
							var tankerinspectionDuplicatesArray = [];
							tankerinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "02" && objfilter.TaskCodeType.length > 0;
							});
							tankerinspectionsArray.forEach(function (objTanker) {

								switch (objTanker.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/tankerinspections")
									objTaskCode1 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTanker.Taskcode);
									objTaskCode1[0].remarks = objTanker.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/tankerinspections")
									objTaskCode2 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTanker.Taskcode);
									objTaskCode2[0].remarks = objTanker.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/tankerinspections")
									objTaskCode3 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTanker.Taskcode);
									objTaskCode3[0].remarks = objTanker.Remarks;
									objTaskCode3[0].fail = true;

									break;
								case "GAS":
									var objTaskCode4 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/tankerinspections")
									objTaskCode4 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTanker.Taskcode)
									objTaskCode4[0].remarks = objTanker.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var tankerItem = this.getView().getModel("data").getProperty("/tankerinspections");
							tankerItem.forEach(function (objTankerItem) {
								if (!objTankerItem.pass && !objTankerItem.fail) {
									objTankerItem.pass = true
								}
							});
							var tankerTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "02";
							});
							tankerTyreData.forEach(function (tankerTyreObj) {
								var arrTyreData = [];
								var tankerTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = tankerTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === tankerTyreObj.TyreNo && tyreObj.ChecklistCat === "02";
								});
								arrTyreData[0].TreadDepth = tankerTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = tankerTyreObj.TyrePsi;

							}.bind(this))

							this.getView().getModel("data").refresh(true);
							break;

						case "FLEET_BT":
							this.getView().getModel('data').setProperty('/documentinspections', []);
							this.getView().byId("idTableDoc").setVisible(false);
							this.getView().byId("idFormDoc").setVisible(false);
							this.getView().byId("idTankId").setVisible(false);
							var truckinspectionsArray = [];
							var truckinspectionDuplicatesArray = [];
							truckinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "01" && objfilter.TaskCodeType.length > 0;
							});
							truckinspectionsArray.forEach(function (objTruck) {

								switch (objTruck.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/bTruckinspections")
									objTaskCode1 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTruck.Taskcode);
									objTaskCode1[0].remarks = objTruck.Remarks;
									objTaskCode1[0].fail = true;

									break;
								case "WELD":
									var objTaskCode2 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/bTruckinspections");
									objTaskCode2 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTruck.Taskcode);
									objTaskCode2[0].remarks = objTruck.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/bTruckinspections")
									objTaskCode3 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTruck.Taskcode);
									objTaskCode3[0].remarks = objTruck.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/bTruckinspections")
									objTaskCode4 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTruck.Taskcode)
									objTaskCode4[0].remarks = objTruck.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var truckItem = this.getView().getModel("data").getProperty("/allData/bTruckinspections");
							truckItem.forEach(function (objTruckItem) {
								if (!objTruckItem.pass && !objTruckItem.fail) {
									objTruckItem.pass = true
								}
							});
							this.getView().getModel('data').setProperty('/truckinspections', truckItem);
							var truckTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "01";
							});
							truckTyreData.forEach(function (truckTyreObj) {
								var arrTyreData = [];
								var truckTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = truckTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === truckTyreObj.TyreNo && tyreObj.ChecklistCat === "01";
								});
								arrTyreData[0].TreadDepth = truckTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = truckTyreObj.TyrePsi;

							}.bind(this));

							//======Tanker=======================
							var tankerinspectionsArray = [];
							var tankerinspectionDuplicatesArray = [];
							tankerinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "02" && objfilter.TaskCodeType.length > 0;
							});
							tankerinspectionsArray.forEach(function (objTanker) {

								switch (objTanker.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/btankerinspections")
									objTaskCode1 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTanker.Taskcode);
									objTaskCode1[0].remarks = objTanker.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/btankerinspections")
									objTaskCode2 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTanker.Taskcode);
									objTaskCode2[0].remarks = objTanker.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/btankerinspections")
									objTaskCode3 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTanker.Taskcode);
									objTaskCode3[0].remarks = objTanker.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/tankerinspections")
									objTaskCode4 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTanker.Taskcode)
									objTaskCode4[0].remarks = objTanker.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var tankerItem = this.getView().getModel("data").getProperty("/allData/btankerinspections");
							tankerItem.forEach(function (objTankerItem) {
								if (!objTankerItem.pass && !objTankerItem.fail) {
									objTankerItem.pass = true
								}
							});
							this.getView().getModel('data').setProperty('/tankerinspections', tankerItem);
							var tankerTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "02";
							});
							tankerTyreData.forEach(function (tankerTyreObj) {
								var arrTyreData = [];
								var tankerTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = tankerTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === tankerTyreObj.TyreNo && tyreObj.ChecklistCat === "02";
								});
								arrTyreData[0].TreadDepth = tankerTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = tankerTyreObj.TyrePsi;

							}.bind(this))

							this.getView().getModel("data").refresh(true);

							break;
						case "FLEET_FK":
							this.getView().getModel('data').setProperty('/documentinspections', []);
							this.getView().getModel('data').setProperty('/truckinspections', []);
							this.getView().byId("idTableDoc").setVisible(false);
							this.getView().byId("idFormDoc").setVisible(false);
							this.getView().byId("sMembershipOvpPageId").setVisible(false);
							this.getView().byId("idFormTruck").setVisible(false);
							this.getView().byId("idTankId").setVisible(false);
							//======Tanker=======================
							var tankerinspectionsArray = [];
							var tankerinspectionDuplicatesArray = [];
							tankerinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "02" && objfilter.TaskCodeType.length > 0;
							});
							tankerinspectionsArray.forEach(function (objTanker) {

								switch (objTanker.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/forkliftinspections")
									objTaskCode1 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTanker.Taskcode);
									objTaskCode1[0].remarks = objTanker.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/forkliftinspections")
									objTaskCode2 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTanker.Taskcode);
									objTaskCode2[0].remarks = objTanker.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/forkliftinspections")
									objTaskCode3 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTanker.Taskcode);
									objTaskCode3[0].remarks = objTanker.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/forkliftinspections")
									objTaskCode4 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTanker.Taskcode)
									objTaskCode4[0].remarks = objTanker.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var tankerItem = this.getView().getModel("data").getProperty("/allData/forkliftinspections");
							tankerItem.forEach(function (objTankerItem) {
								if (!objTankerItem.pass && !objTankerItem.fail) {
									objTankerItem.pass = true
								}
							});
							this.getView().getModel('data').setProperty('/tankerinspections', tankerItem);

							var tankerTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "02";
							});
							tankerTyreData.forEach(function (tankerTyreObj) {
								var arrTyreData = [];
								var tankerTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = tankerTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === tankerTyreObj.TyreNo && tyreObj.ChecklistCat === "02";
								});
								arrTyreData[0].TreadDepth = tankerTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = tankerTyreObj.TyrePsi;

							}.bind(this))

							this.getView().getModel("data").refresh(true);
							break;
						case "FLEET_FB":
							this.getView().getModel('data').setProperty('/documentinspections', []);
							this.getView().byId("idTableDoc").setVisible(false);
							this.getView().byId("idFormDoc").setVisible(false);
							this.getView().byId("idTankId").setVisible(false);
							var truckinspectionsArray = [];
							var truckinspectionDuplicatesArray = [];
							truckinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "01" && objfilter.TaskCodeType.length > 0;
							});
							truckinspectionsArray.forEach(function (objTruck) {
								switch (objTruck.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/flatTruckinspections")
									objTaskCode1 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTruck.Taskcode);
									objTaskCode1[0].remarks = objTruck.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/flatTruckinspections");
									objTaskCode2 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTruck.Taskcode);
									objTaskCode2[0].remarks = objTruck.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/flatTruckinspections")
									objTaskCode3 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTruck.Taskcode);
									objTaskCode3[0].remarks = objTruck.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var truckItem = this.getView().getModel("data").getProperty("/allData/flatTruckinspections")
									objTaskCode4 = truckItem.filter(function (truckObj) {
										return truckObj.slno === parseInt(objTruck.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTruck.Taskcode)
									objTaskCode4[0].remarks = objTruck.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var truckItem = this.getView().getModel("data").getProperty("/allData/flatTruckinspections");
							truckItem.forEach(function (objTruckItem) {
								if (!objTruckItem.pass && !objTruckItem.fail) {
									objTruckItem.pass = true
								}
							});
							var truckTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "01";
							});
							truckTyreData.forEach(function (truckTyreObj) {
								var arrTyreData = [];
								var truckTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = truckTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === truckTyreObj.TyreNo && tyreObj.ChecklistCat === "01";
								});
								arrTyreData[0].TreadDepth = truckTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = truckTyreObj.TyrePsi;

							}.bind(this));

							//======Tanker=======================
							var tankerinspectionsArray = [];
							var tankerinspectionDuplicatesArray = [];
							tankerinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "02" && objfilter.TaskCodeType.length > 0;
							});
							tankerinspectionsArray.forEach(function (objTanker) {

								switch (objTanker.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode1 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTanker.Taskcode);
									objTaskCode1[0].remarks = objTanker.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode2 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTanker.Taskcode);
									objTaskCode2[0].remarks = objTanker.Remarks;
									objTaskCode2[0].fail = true;
									break;
								case "ELEC":
									var objTaskCode3 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode3 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTanker.Taskcode);
									objTaskCode3[0].remarks = objTanker.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode4 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTanker.Taskcode)
									objTaskCode4[0].remarks = objTanker.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections");
							tankerItem.forEach(function (objTankerItem) {
								if (!objTankerItem.pass && !objTankerItem.fail) {
									objTankerItem.pass = true
								}
							});
							this.getView().getModel('data').setProperty('/truckinspections', truckItem);
							this.getView().getModel('data').setProperty('/tankerinspections', tankerItem);

							var tankerTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "02";
							});
							tankerTyreData.forEach(function (tankerTyreObj) {
								var arrTyreData = [];
								var tankerTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = tankerTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === tankerTyreObj.TyreNo && tyreObj.ChecklistCat === "02";
								});
								arrTyreData[0].TreadDepth = tankerTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = tankerTyreObj.TyrePsi;

							}.bind(this))
							this.getView().getModel("data").refresh(true);
							break;
						case "FLEET_CR":
							this.getView().getModel('data').setProperty('/documentinspections', []);
							this.getView().getModel('data').setProperty('/truckinspections', []);
							this.getView().byId("idTableDoc").setVisible(false);
							this.getView().byId("idFormDoc").setVisible(false);
							this.getView().byId("sMembershipOvpPageId").setVisible(false);
							this.getView().byId("idFormTruck").setVisible(false);
							this.getView().byId("idTankId").setVisible(false);
							//======Tanker=======================
							var tankerinspectionsArray = [];
							var tankerinspectionDuplicatesArray = [];
							tankerinspectionsArray = oData.results[0].NAVCHLPOST.results.filter(function (objfilter) {
								return objfilter.ChcklistCat === "02" && objfilter.TaskCodeType.length > 0;
							});
							tankerinspectionsArray.forEach(function (objTanker) {

								switch (objTanker.TaskCodeType) {
								case "MECH":
									var objTaskCode1 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode1 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode1[0].taskcode1.push(objTanker.Taskcode);
									objTaskCode1[0].remarks = objTanker.Remarks;
									objTaskCode1[0].fail = true;
									break;
								case "WELD":
									var objTaskCode2 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode2 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode2[0].taskcode2.push(objTanker.Taskcode);
									objTaskCode2[0].remarks = objTanker.Remarks;
									objTaskCode2[0].fail = true;

									break;
								case "ELEC":
									var objTaskCode3 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode3 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode3[0].taskcode3.push(objTanker.Taskcode);
									objTaskCode3[0].remarks = objTanker.Remarks;
									objTaskCode3[0].fail = true;
									break;
								case "GAS":
									var objTaskCode4 = [];
									var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections")
									objTaskCode4 = tankerItem.filter(function (tankerObj) {
										return tankerObj.slno === parseInt(objTanker.ChecklistNo);
									});
									objTaskCode4[0].taskcode4.push(objTanker.Taskcode)
									objTaskCode4[0].remarks = objTanker.Remarks;
									objTaskCode4[0].bEditable = true;
									objTaskCode4[0].fail = true;
									break;
								default:
								}
							}.bind(this));
							var tankerItem = this.getView().getModel("data").getProperty("/allData/flabinspections");
							tankerItem.forEach(function (objTankerItem) {
								if (!objTankerItem.pass && !objTankerItem.fail) {
									objTankerItem.pass = true
								}
							});

							this.getView().getModel('data').setProperty('/tankerinspections', tankerItem);
							var tankerTyreData = oData.results[0].NAVTYRESDATA.results.filter(function (objfilter) {
								return objfilter.ChecklistCat === "02";
							});
							tankerTyreData.forEach(function (tankerTyreObj) {
								var arrTyreData = [];
								var tankerTyre = this.getView().getModel("data").getProperty("/tyreInspection");
								arrTyreData = tankerTyre.filter(function (tyreObj) {
									return tyreObj.TyreNo === tankerTyreObj.TyreNo && tyreObj.ChecklistCat === "02";
								});
								arrTyreData[0].TreadDepth = tankerTyreObj.TreadDepth;
								arrTyreData[0].TyrePsi = tankerTyreObj.TyrePsi;
							}.bind(this))

							this.getView().getModel("data").refresh(true);
							break;
						default:
						}
					}
					that.onEditablefields(false);

				}.bind(this),
				error: function (oError) {}
			});
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onPrint: function (oEvent) {
			var oTarget = this.getView();
			// var oTarget = this.getView().byId("dynamicPageId");
			var $domTarget = oTarget.$()[0],
				sTargetContent = $domTarget.innerHTML,
				sOriginalContent = document.body.innerHTML;

			document.body.innerHTML = sTargetContent;
			window.print();
			document.body.innerHTML = sOriginalContent;
			// window.location.reload();
		},
		onPrint1: function (oEvent) {
			var mywindow = window.open('', 'PRINT', 'height=400,width=600');
			var oTarget = this.getView();
			// var oTarget = this.getView().byId("dynamicPageId");
			var $domTarget = oTarget.$()[0],
				sTargetContent = $domTarget.innerHTML;
			var sOriginalContent = document.body.innerHTML;
			// mywindow.document.write('<html><head><title>' + document.title + '</title>');
			// mywindow.document.write('</head><body >');
			// mywindow.document.write('<h1>' + document.title + '</h1>');
			// mywindow.document.write(document.getElementById(elem).innerHTML);
			// mywindow.document.write(sTargetContent);
			// mywindow.document.write('</body></html>');
			mywindow.document.body.innerHTML = sOriginalContent;
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10*/

			mywindow.print();
			mywindow.close();

			return true;
		},
		onClosePress: function () {
			setTimeout(() => {
				// this._oWizard.setCurrentStep(this._oWizard.getSteps()[2]);
				// this._oWizard.setCurrentStep(this._oWizard.getSteps()[0]);
				this._oWizard.goToStep(this._oWizard.getSteps()[this._iSelectedStepIndex]);
				this.getView().setBusy(false)
				this.bValidated = true;
				this.setViewData();
				this.onEditablefields(true);
				this.getView().getModel("data").setProperty("/ObjSelectedType", "FLEET_TK");
				this.getRouter().navTo("OverView");
			}, 2000)
			this.getView().setBusy(true)
			this.getView().getModel('data').refresh(true);
			// this._oWizard.setCurrentStep(this._oWizard.getSteps()[1]);
			this._oWizard.setCurrentStep(this._oWizard.getSteps()[0]);

			this._iSelectedStepIndex = 0;
			this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex]

			this.handleVisibility();
			//Refresh Files in sections
			this.getView().getModel('data').setProperty('/truckFiles', []);
			this.getView().getModel('data').setProperty('/tankFiles', []);
			this.getView().byId('idInspNo').setText("");
			this.getView().byId('idPNotif').setText("");
			this.getView().byId('idSNotif').setText("");
			this.getView().byId('idLoc').setSelectedKey("");
			this.getView().byId('iDInspType').setSelectedKey("");
			this.getView().byId('idPlant').setSelectedKey("")
			this.getView().byId('idCC').setSelectedKey("")
			this.getView().byId('iDobjType').setSelectedKey("")
			this.getView().byId('idDriver').setValue("")
			this.getView().byId('idDriverName').setText("")
			this.getView().byId('idTruckId').setValue("")
			this.getView().byId('idTankId').setValue("")
			this.oStatus = ""
		},
		handleNavigationChange: function (oEvent) {
			// this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === oEvent.getParameter('step').sId)
			// this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex]
			// this.handleVisibility();
		},
		setViewData: function (data) {
			var oData = {
				//Flatbed
				flatTruckinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('flat1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('flat2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('flat3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('flat4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('flat5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('flat6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('flat7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('flat8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('flat9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('flat10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('flat11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('flat12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('flat13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('flat14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('flat15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''

				}],
				flabinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('flab1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('flab2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('flab3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('flab4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('flab5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('flab6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('flab7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('flab8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('flab9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('flab10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('flab11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('flab12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}],

				//Forklift
				forkliftinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('fork1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('fork2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('fork3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('fork4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('fork5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('fork6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('fork7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('fork8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('fork9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('fork10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('fork11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('fork12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('fork13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('fork14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('fork15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''

				}],

				//isuzu
				isuzuinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('isdy1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('isdy2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('isdy3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('isdy4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('isdy5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('isdy6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('isdy7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('isdy8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('isdy9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('isdy10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('isdy11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('isdy12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('isdy13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('isdy14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('isdy15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''

				}],

				items: [{
					description: 'Item1',
					key: '1'
				}, {
					description: 'Item2',
					key: '2'
				}, {
					description: 'Item3',
					key: '3'
				}, {
					description: 'Item4',
					key: '4'
				}],
				valueitems: [{
					value: 'Item1',
					key: '1'
				}, {
					value: 'Item2',
					key: '2'
				}, {
					value: 'Item3',
					key: '3'
				}, {
					value: 'Item4',
					key: '4'
				}],
				subobjects: [{
					value: 'Item1',
					key: '1'
				}, {
					description: 'Item2',
					key: '2'
				}, {
					description: 'Item3',
					key: '3'
				}],
				tyreInspection: [{
					ObjectType: "",
					TyreNo: "01",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "01",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "02",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "02",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "03",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "03",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "04",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "04",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "05",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "05",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "06",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "06",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "07",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "07",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "08",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "08",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "09",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "09",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "10",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "10",
					ChecklistCat: "01"
				}, {
					ObjectType: "",
					TyreNo: "01",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "11",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "02",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "12",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "03",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "13",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "04",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "14",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "05",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "15",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "06",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "16",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "07",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "17",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "08",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "18",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "09",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "19",
					ChecklistCat: "02"
				}, {
					ObjectType: "",
					TyreNo: "10",
					TreadDepth: "",
					TyrePsi: "",
					InspId: "",
					Iteration: "20",
					ChecklistCat: "02"
				}],
				tyreValues: [{
					tyreCode: "1",
					tyreValue: "1"
				}, {
					tyreCode: "2",
					tyreValue: "2"
				}, {
					tyreCode: "3",
					tyreValue: "3"
				}, {
					tyreCode: "4",
					tyreValue: "4"
				}, {
					tyreCode: "5",
					tyreValue: "5"
				}, {
					tyreCode: "6",
					tyreValue: "6"
				}, {
					tyreCode: "7",
					tyreValue: "7"
				}, {
					tyreCode: "8",
					tyreValue: "8"
				}, {
					tyreCode: "9",
					tyreValue: "9"
				}, {
					tyreCode: "10",
					tyreValue: "10"
				}],
				tyrePSIValues: [{
					tyreCode: "25",
					tyreValue: "25"
				}, {
					tyreCode: "26",
					tyreValue: "26"
				}, {
					tyreCode: "27",
					tyreValue: "27"
				}, {
					tyreCode: "28",
					tyreValue: "28"
				}, {
					tyreCode: "29",
					tyreValue: "29"
				}, {
					tyreCode: "30",
					tyreValue: "30"
				}, {
					tyreCode: "31",
					tyreValue: "31"
				}, {
					tyreCode: "32",
					tyreValue: "32"
				}, {
					tyreCode: "33",
					tyreValue: "33"
				}, {
					tyreCode: "34",
					tyreValue: "34"
				}],

				//Check Document Inspection
				documentinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('docins1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('docins2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('docins3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('docins4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('docins5'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('docins6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('docins7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('docins8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('docins9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('docins10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('docins11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('docins12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('docins13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('docins14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('docins15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 16,
					description: this.oResourceBundle.getText('docins16'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 17,
					description: this.oResourceBundle.getText('docins17'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 18,
					description: this.oResourceBundle.getText('docins18'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 19,
					description: this.oResourceBundle.getText('docins19'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 20,
					description: this.oResourceBundle.getText('docins20'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 21,
					description: this.oResourceBundle.getText('docins21'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 22,
					description: this.oResourceBundle.getText('docins22'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 23,
					description: this.oResourceBundle.getText('docins23'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 24,
					description: this.oResourceBundle.getText('docins24'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 25,
					description: this.oResourceBundle.getText('docins25'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 26,
					description: this.oResourceBundle.getText('docins26'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''

				}],
				truckinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('truckins1'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('truckins2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('truckins3'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('truckins4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('truckins5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('truckins6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('truckins7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('truckins8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('truckins9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('truckins10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('truckins11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('truckins12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('truckins13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('truckins14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('truckins15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 16,
					description: this.oResourceBundle.getText('truckins16'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 17,
					description: this.oResourceBundle.getText('truckins17'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}],
				tankerinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('tankins1'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('tankins2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('tankins3'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('tankins4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('tankins5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('tankins6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('tankins7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('tankins8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('tankins9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('tankins10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('tankins11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('tankins12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('tankins13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('tankins14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('tankins15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 16,
					description: this.oResourceBundle.getText('tankins16'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 17,
					description: this.oResourceBundle.getText('tankins17'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 18,
					description: this.oResourceBundle.getText('tankins18'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 19,
					description: this.oResourceBundle.getText('tankins19'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 20,
					description: this.oResourceBundle.getText('tankins20'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 21,
					description: this.oResourceBundle.getText('tankins21'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 22,
					description: this.oResourceBundle.getText('tankins22'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 23,
					description: this.oResourceBundle.getText('tankins23'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}],
				//Bobtail Daily Pretrip Inspection(Truck)
				bTruckinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('bobtruck1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('bobtruck2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('bobtruck3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('bobtruck4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('bobtruck5'),
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('bobtruck6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('bobtruck7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('bobtruck8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('bobtruck9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('bobtruck10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('bobtruck11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('bobtruck12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('bobtruck13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('bobtruck14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('bobtruck15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 16,
					description: this.oResourceBundle.getText('bobtruck16'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}],
				btankerinspections: [{
					slno: 1,
					description: this.oResourceBundle.getText('bobtanker1'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 2,
					description: this.oResourceBundle.getText('bobtanker2'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 3,
					description: this.oResourceBundle.getText('bobtanker3'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 4,
					description: this.oResourceBundle.getText('bobtanker4'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 5,
					description: this.oResourceBundle.getText('bobtanker5'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 6,
					description: this.oResourceBundle.getText('bobtanker6'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 7,
					description: this.oResourceBundle.getText('bobtanker7'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 8,
					description: this.oResourceBundle.getText('bobtanker8'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 9,
					description: this.oResourceBundle.getText('bobtanker9'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 10,
					description: this.oResourceBundle.getText('bobtanker10'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 11,
					description: this.oResourceBundle.getText('bobtanker11'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 12,
					description: this.oResourceBundle.getText('bobtanker12'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 13,
					description: this.oResourceBundle.getText('bobtanker13'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 14,
					description: this.oResourceBundle.getText('bobtanker14'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 15,
					description: this.oResourceBundle.getText('bobtanker15'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}, {
					slno: 16,
					description: this.oResourceBundle.getText('bobtanker16'),
					taskType: "",
					groupCode: "",
					groupName: "",
					bEditable: false,
					pass: false,
					fail: false,
					taskcode1: [],
					taskcode2: [],
					taskcode3: [],
					taskcode4: [],
					countcode: [],
					failcode: [],
					remarks: ''
				}]

			};

			//	this.getView().getModel('data').setProperty('/inspectionsummary', oData.inspectionsummary);

			// this.getView().getModel('data').setProperty('/subobjects', oData.subobjects);
			this.getView().getModel('data').setProperty('/tyreValues', oData.tyreValues);
			this.getView().getModel('data').setProperty('/tyrePSIValues', oData.tyrePSIValues);
			// this.getView().getModel('data').setProperty('/valueitems', oData.valueitems);
			this.getView().getModel('data').setProperty('/documentinspections', oData.documentinspections);
			this.getView().getModel('data').setProperty('/truckinspections', oData.truckinspections);
			this.getView().getModel('data').setProperty('/tankerinspections', oData.tankerinspections);
			// this.getView().getModel('data').setProperty('/items', oData.valueitems);
			this.getView().getModel('data').setProperty('/tyreInspection', oData.tyreInspection);

			this.getView().getModel('data').setProperty('/docpass', 0);
			this.getView().getModel('data').setProperty('/docfail', 0);
			this.getView().getModel('data').setProperty('/truckpass', 0);
			this.getView().getModel('data').setProperty('/truckfail', 0);
			this.getView().getModel('data').setProperty('/tankerpass', 0);
			this.getView().getModel('data').setProperty('/tankerfail', 0);
			this.getView().getModel('data').setProperty('/allData', oData);
			// this.getView().byId('SSubObjId').setSelectedKey("")
			this.getView().getModel('data').setProperty('/preventivesch', new Date());
			this.getView().getModel('data').setProperty('/trprvntsch', new Date());
		},
		getInitLoad: function () {
			//Get Default Model
			this.oModel = this.getOwnerComponent().getModel();
			var that = this;
			var k = [];
			this._oBusyDialog.open();
			//Get Dropdown Data
			//Read Dropdown values 
			this.oModel.read("/ES_F4_INITSet", {
				filters: [new sap.ui.model.Filter("F4Id", "EQ", "INIT")],
				urlParameters: {
					$expand: "NAVINSPLOC,NAVINSPTYPE,NAVOBJTYPE,NAVPLANT,NAVTASKCODES,NAVOPWCNTR,NAVCOSTCENTER"
				},
				success: function (oData) {
					oData.results.forEach(function (element, i) {
						if (that.sInp) {
							that.getInspectData(that.sInp);
						}
						//Inspector ID & Name

						that.InspectorId = element.InspId;
						that.InspectorName = element.InspName;
						that.getView().getModel('data').setProperty('/inspID', that.InspectorId);
						that.getView().getModel('data').setProperty('/inspName', that.InspectorName);
						// 		
						//Inspection Location
						if (element.NAVINSPLOC.results.length > 0) {
							that.getView().getModel('data').setProperty('/InspLoc', element.NAVINSPLOC.results);
						}
						// Inspection Type
						if (element.NAVINSPTYPE.results.length > 0) {
							that.getView().getModel('data').setProperty('/InspType', element.NAVINSPTYPE.results);
						}
						// Object Type
						if (element.NAVOBJTYPE.results.length > 0) {
							that.getView().getModel('data').setProperty('/ObjType', element.NAVOBJTYPE.results);
						}
						// Plant
						if (element.NAVPLANT.results.length > 0) {
							that.getView().getModel('data').setProperty('/Plant', element.NAVPLANT.results);
						}
						//Cost Center
						if (element.NAVCOSTCENTER.results.length > 0) {
							that.getView().getModel('data').setProperty('/CostCenter', element.NAVCOSTCENTER.results);
						}
						//  Task Codes
						//  
						if (element.NAVTASKCODES.results.length > 0) {
							element.NAVTASKCODES.results.forEach(function (e, i) {
								switch (e.TASK_CODE_TYPE) {
								case "MECH":
									if (!that.tCode1) {
										that.tCode1 = [];
									}
									that.tCode1.push({
										TASK_CODE: e.TASK_CODE,
										TASK_DESCR: e.TASK_DESCR,
										TASK_CODE_TYPE: e.TASK_CODE_TYPE,
										GROUP_CODE: e.GROUP_CODE,
										GROUP_NAME: e.GROUP_NAME
									})
									break;
								case "WELD":
									if (!that.countcode) {
										that.tCode2 = [];
									}
									that.tCode2.push({
										TASK_CODE: e.TASK_CODE,
										TASK_DESCR: e.TASK_DESCR,
										TASK_CODE_TYPE: e.TASK_CODE_TYPE,
										GROUP_CODE: e.GROUP_CODE,
										GROUP_NAME: e.GROUP_NAME
									})
									break;
								case "ELEC":
									if (!that.tCode3) {
										that.tCode3 = [];
									}
									that.tCode3.push({
										TASK_CODE: e.TASK_CODE,
										TASK_DESCR: e.TASK_DESCR,
										TASK_CODE_TYPE: e.TASK_CODE_TYPE,
										GROUP_CODE: e.GROUP_CODE,
										GROUP_NAME: e.GROUP_NAME
									})
									break;
								case "GAS":
									if (!that.tCode4) {
										that.tCode4 = [];
									}
									that.tCode4.push({
										TASK_CODE: e.TASK_CODE,
										TASK_DESCR: e.TASK_DESCR,
										TASK_CODE_TYPE: e.TASK_CODE_TYPE,
										GROUP_CODE: e.GROUP_CODE,
										GROUP_NAME: e.GROUP_NAME
									})
									break;
								case "TYRE":
									if (!that.tCode2) {
										that.tCode2 = [];
									}
									that.tCode2.push({
										TASK_CODE: e.TASK_CODE,
										TASK_DESCR: e.TASK_DESCR,
										TASK_CODE_TYPE: e.TASK_CODE_TYPE,
										GROUP_CODE: e.GROUP_CODE,
										GROUP_NAME: e.GROUP_NAME
									})
									break;
								default:
								}
							})
							that.getView().getModel('data').setProperty('/Altaskcode1', that.tCode1);
							that.getView().getModel('data').setProperty('/Altaskcode2', that.tCode2);
							that.getView().getModel('data').setProperty('/Altaskcode3', that.tCode3);
							that.getView().getModel('data').setProperty('/Altaskcode4', that.tCode4);
						}
						// Work Center
						if (element.NAVOPWCNTR.results.length > 0) {
							that.getView().getModel('data').setProperty('/WorkCenter', element.NAVOPWCNTR.results);
						}
						that.setViewData();
						that.onEditablefields(true);
						that._oBusyDialog.close();
					})
				}.bind(this),
				error: function (oError) {}
			});
		},
		onValueHelpTankerEquipment: function () {
			this.flg = "Tanker";
			var sObjType = this.getView().byId("iDobjType");
			var sPlant = this.getView().byId("idPlant");

			this.oModel.read("/ES_F4_VEHICLESet", {
				filters: [
					new sap.ui.model.Filter("EqType", "EQ", sObjType.getSelectedKey()),
					new sap.ui.model.Filter("UiField", "EQ", "PLANT"),
					// new sap.ui.model.Filter("UiValue", "EQ", sPlant.getSelectedKey()
					new sap.ui.model.Filter("UiValue", "EQ", this.flg)
				],
				success: function (oData) {
					this._Equipment = sap.ui.xmlfragment("Equipment", "com.gascozgasco.fragment.Equipment", this);
					this._Equipment.setModel(new sap.ui.model.json.JSONModel(oData), "equipmentModel");
					this._Equipment.open();
				}.bind(this),
				error: function (oError) {}
			});
		},
		onValueHelpTruckEquipment: function (oEvent) {
			this.flg = "Truck";
			var sObjType = this.getView().byId("iDobjType");
			var sPlant = this.getView().byId("idPlant");
			this.oModel.read("/ES_F4_VEHICLESet", {
				filters: [
					new sap.ui.model.Filter("EqType", "EQ", sObjType.getSelectedKey()),
					new sap.ui.model.Filter("UiField", "EQ", "PLANT"),
					new sap.ui.model.Filter("UiValue", "EQ", sPlant.getSelectedKey())
				],
				success: function (oData) {
					this._Equipment = sap.ui.xmlfragment("Equipment", "com.gascozgasco.fragment.Equipment", this);
					this._Equipment.setModel(new sap.ui.model.json.JSONModel(oData), "equipmentModel");
					this._Equipment.open();
				}.bind(this),
				error: function (oError) {}
			});

		},
		onValueHelpDriver: function (oEvent) {
			//Check Plant for ValueHelp
			var sPlant = this.getView().byId("idPlant");
			this._oBasicSearchField = new SearchField();
			if (this._Driver) {
				this._Driver.destroy();
				this._Driver = null;
			}

			var oView = this.getView();
			if (!this._Driver) {

				this.oModel.read("/ES_F4_DRIVERID_NAMESet", {
					filters: [new sap.ui.model.Filter("UiField", "EQ", "PLANT"),
						new sap.ui.model.Filter("UiValue", "EQ", sPlant.getSelectedKey())
					],
					success: function (oData) {
						this._Driver = sap.ui.xmlfragment("driver", "com.gascozgasco.fragment.driver", this);
						this._Driver.setModel(new sap.ui.model.json.JSONModel(oData), "driversModel");
						this._Driver.open();
					}.bind(this),
					error: function (oError) {}
				});
			}
		},
		onFilterBarSearch: function (oEvent) {
			var sSearchQuery = this._oBasicSearchField.getValue(),
				aSelectionSet = oEvent.getParameter("selectionSet");

			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			aFilters.push(new Filter({
				filters: [
					new Filter({
						path: "Plant",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					new Filter({
						path: "DriverName",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					})
				],
				and: false
			}));

			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},
		onValueHelpDriverOkPress: function (oEvent) {
			this._Driver.close();
		},
		onValueHelpDriverCancelPress: function (oEvent) {
			this._Driver.close();
		},
		onValueHelpAfterClose: function (oEvent) {
			this._Driver.close();
		},
		handleValueHelpClose: function (oEvent) {
			var obj = oEvent.getParameter('selectedItem').getBindingContext('driversModel').getObject();
			this.getView().getModel('data').setProperty('/DriverId', obj.DriverId);
			this.getView().getModel('data').setProperty('/DriverName', obj.DriverName);
		},
		handleEquipmentValueHelpClose: function (oEvent) {
			var obj = oEvent.getParameter('selectedItem').getBindingContext('equipmentModel').getObject();
			if (this.flg === "Truck") {
				this.getView().getModel('data').setProperty('/Pequip', obj.Vehicle);
				this.getView().byId("idTruckId").setValue(obj.Vehicle);
			} else {
				this.getView().getModel('data').setProperty('/Cequip', obj.Vehicle);
				this.getView().byId("idTankId").setValue(obj.Vehicle);
				// Tanker Tire based on Old and New tanker
				var tankNo = obj.Vehicle;
				var tankTh = "TN-0900";
				const tCompare = tankNo.localeCompare(tankTh);
				// 1 if tankNo is greater (higher in the alphabetical order) than tankTh => NEW
				// -1 if tankNo is smaller (lower in the alphabetical order) than tankTh => OLD Model 8 Tires
				// 0 if tankTh and tankTh are equal in the alphabetical order => NEW Model 6 tires
				if (tCompare >= 0) {
					this.getView().byId("idTank7").setVisible(false);
					this.getView().byId("idTank7Image").setVisible(false);
					this.getView().byId("idTank8Image").setVisible(false);
					this.getView().byId("idTank8").setVisible(false);
					this.getView().byId("idTankMiddle2").setVisible(true);
					this.getView().byId("idTankMiddle1").setVisible(false);
					this.getView().byId("idTankLast1").setVisible(true);
					this.getView().byId("idTankLast2").setVisible(false);
				} else if (tCompare === -1) {
					this.getView().byId("idTankLast2").setVisible(true);
					this.getView().byId("idTankLast1").setVisible(false);
					this.getView().byId("idTank7").setVisible(true);
					this.getView().byId("idTank7Image").setVisible(true);
					this.getView().byId("idTank8Image").setVisible(true);
					this.getView().byId("idTank8").setVisible(true);
				}
			}
		},
		handleEquipmentSearch: function (oEvent) {
			var aFilter = [];
			var sValue = oEvent.getParameter("value");
			aFilter.push(new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("Vehicle", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue));
			var oBinding = oEvent.getSource().getBinding("items");
			var orFilters = new sap.ui.model.Filter(aFilter, false);
			oBinding.filter(orFilters);
		},
		handleSearch: function (oEvent) {
			var aFilter = []
			var sValue = oEvent.getParameter("value");
			aFilter.push(new sap.ui.model.Filter("DriverName", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("DriverId", sap.ui.model.FilterOperator.Contains, sValue));
			var orFilters = new sap.ui.model.Filter(aFilter, false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(orFilters);
		},
		handleCount: function (aData, passcount, failcount) {
			var nPass = 0;
			var nFail = 0;
			aData.forEach((oItem) => {
				if (oItem.pass) {
					nPass += 1;
				}
				if (oItem.fail) {
					nFail += 1;
				}
			})
			this.getView().getModel('data').setProperty(passcount, nPass);
			this.getView().getModel('data').setProperty(failcount, nFail);
		},
		onDocumentInspectionCheckSelect: function (oEvent) {
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/docpass', '/docfail');
			if (oSelectedObject.pass) {
				oSelectedObject.pass = false
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}
			if (!oSelectedObject.fail) {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
			} else {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
			}
		},
		onDialogBackButton: function () {
			this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === this._oSelectedStep.sId)
			var oPreviousStep = this._oWizard.getSteps()[this._iSelectedStepIndex - 1];
			// this._oWizard.previousStep();
			// if (this._oSelectedStep) {
			this._oWizard.goToStep(oPreviousStep, true);
			// } else {
			// 	this._oWizard.previousStep();
			// }

			this._iSelectedStepIndex--;
			this.handleVisibility();
			this._oSelectedStep = oPreviousStep;

			// this.handleButtonsVisibility();
		},
		handleVisibility: function () {
			if (this._iSelectedStepIndex === 0) {
				this.getView().getModel('data').setProperty('/previousEnabled', false)
				this.getView().getModel('data').setProperty('/nextEnabled', false)
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/continueEnabled', true)
			} else {
				this.getView().getModel('data').setProperty('/previousEnabled', true)
				this.getView().getModel('data').setProperty('/nextEnabled', true)
				this.getView().getModel('data').setProperty('/continueEnabled', false)
			}
			if (this._iSelectedStepIndex === 4) {
				this.getView().getModel('data').setProperty('/previousEnabled', false);

				if (this.getView().getModel("data").getProperty("/editVisible")) {
					this.getView().getModel('data').setProperty('/submitVisible', false)
				} else {
					this.getView().getModel('data').setProperty('/submitVisible', true)
				}

				this.getView().getModel('data').setProperty('/nextEnabled', false)
				this.getView().getModel('data').setProperty('/closeVisible', true)
				this.getView().getModel('data').setProperty('/continueEnabled', false)
			} else {
				this.getView().getModel('data').setProperty('/closeVisible', false)
			}
			if (this._iSelectedStepIndex === 3) {
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/nextEnabled', true)
			} else if (this._iSelectedStepIndex > 0 && this._iSelectedStepIndex < 4) {
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/nextEnabled', true)
			}
			if (this._iSelectedStepIndex === 5) {
				this.getView().getModel('data').setProperty('/closeVisible', true)
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/nextEnabled', false)

			}
		},
		onTruckInspectionPassCheckSelect: function (oEvent) {
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/truckpass', '/truckfail');
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			if (oSelectedObject.fail) {
				oSelectedObject.fail = false;
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}

			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode1', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode2', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode3', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode4', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/countcode', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/failcode', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
		},
		onTruckInspectionCheckSelect: function (oEvent) {
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/truckpass', '/truckfail');
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			if (oSelectedObject.pass) {
				oSelectedObject.pass = false
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}
			if (oSelectedObject.fail) {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
			} else {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
			}
		},
		onTankerInspectionCheckSelect: function (oEvent) {
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/tankerpass', '/tankerfail');
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			if (oSelectedObject.pass) {
				oSelectedObject.pass = false
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}
			if (oSelectedObject.fail) {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
			} else {
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
			}
		},
		onTankerInspectionPassCheckSelect: function (oEvent) {
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/tankerpass', '/tankerfail');
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			if (oSelectedObject.fail) {
				oSelectedObject.fail = false;
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode1', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode2', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode3', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode4', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/countcode', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/failcode', [])
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
		},
		onDocumentInspectionPassCheckSelect: function (oEvent) {
			var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
				.split(
					'/')[1]);
			this.handleCount(aData, '/docpass', '/docfail');
			var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
			if (oSelectedObject.fail) {
				oSelectedObject.fail = false;
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
			}
			this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
		},
		validateDocument: function () {
			var aData = this.getView().getModel('data').getData()
			var bValid = true;
			var aFailPass = [];
			var docWizard = this.getView().byId("DocumentStep");
			var oTable = docWizard.getContent()[0];
			var aFailPass = aData.documentinspections.filter(function (oItem) {
				return oItem.pass === false && oItem.fail === false;
			})
			if (aFailPass.length > 0) {
				bValid = false;
				this.aMessage = {
					"text": "Please choose all the document inspection"
				};

				return bValid;
			}
			aData.documentinspections.forEach(function (oItem) {
				if (oItem.fail) {
					if (oItem.remarks === '') {
						this.aMessage = {
							"text": "Enter remarks for failed Document checklist!"
						};
						bValid = false
						return bValid;
					}
				}
			}.bind(this))
			return bValid;
		},
		validateTruckandTanker: function (aData, sText) {
			var bValid = true;
			var aFailPass = [];
			var aFailPass = aData.filter(function (oItem) {
				return oItem.pass === false && oItem.fail === false;
			});
			if (aFailPass.length > 0) {
				bValid = false;
				this.aMessage = {
					"text": "Please fill all the " + sText + " Inspection checklists."
				};
				return bValid;
			}
			aData.forEach(function (oItem) {
				if (oItem.fail && sText === "Truck") {
					if (!oItem.taskcode3) {
						oItem.taskcode3 = [];
					}
					if (!oItem.taskcode4) {
						oItem.taskcode4 = [];
					}
					if (oItem.remarks === '' || (oItem.taskcode1.length === 0 &&
							oItem.taskcode2.length === 0 && oItem.taskcode3.length === 0 && oItem.taskcode4.length === 0)) {
						this.aMessage = {
							// "text": "Please choose taskcode or enter remarks if it " + sText + " inspection is fail"
							"text": "Choose relevant task code & enter remarks for the failed " + sText + " Inspection checklist."
						};
						bValid = false
					}
				} else if (oItem.fail && sText === "Tanker") {
					if (!oItem.taskcode3) {
						oItem.taskcode3 = [];
					}
					if (!oItem.taskcode4) {
						oItem.taskcode4 = [];
					}
					if (oItem.remarks === '' || (oItem.taskcode1.length === 0 &&
							oItem.taskcode2.length === 0 && oItem.taskcode3.length === 0 && oItem.taskcode4.length === 0)) {
						this.aMessage = {
							// "text": "Please enter remarks if it " + sText + " inspection is fail"
							"text": "Choose relevant task code & enter remarks for the failed " + sText + " Inspection checklist."
						};
						bValid = false
					}
				}
			}.bind(this))
			return bValid;
		},
		validateTankerTyreData: function (data) {
			var bValid = true;
			var tankNo = this.getView().byId('idTankId').getValue();
			var tankTh = "TN-0900";
			const tCompare = tankNo.localeCompare(tankTh);
			if (this.getView().byId('iDobjType').getSelectedKey() != "FLEET_TK") {
				tCompare = 0;
			}
			// 1 if tankNo is greater (higher in the alphabetical order) than tankTh => NEW
			// -1 if tankNo is smaller (lower in the alphabetical order) than tankTh => OLD Model 8 Tires
			// 0 if tankTh and tankTh are equal in the alphabetical order => NEW Model 6 tires
			if ((tCompare === -1) &&
				// data[10].TreadDepth.length === 0 || data[10].TyrePsi.length === 0 ||
				(data[10].TreadDepth.length === 0 || data[10].TyrePsi.length === 0 || data[11].TreadDepth.length === 0 || data[11].TyrePsi.length ===
					0 || data[12].TreadDepth.length === 0 || data[12].TyrePsi.length === 0 || data[13].TreadDepth.length === 0 || data[13].TyrePsi.length ===
					0 || data[14].TreadDepth.length === 0 || data[14].TyrePsi.length === 0 || data[15].TreadDepth.length === 0 || data[15].TyrePsi.length ===
					0 || data[16].TreadDepth.length === 0 || data[16].TyrePsi.length === 0 || data[17].TreadDepth.length === 0 || data[17].TyrePsi.length ===
					0)
				// 0 || data[18].TreadDepth.length === 0 || data[18].TyrePsi.length === 0 || data[19].TreadDepth.length === 0 || data[19].TyrePsi.length ===0
			) {
				this.aMessage = {
					"text": "Please select Tanker Tire data using dropdown"
				};
				bValid = false
				return bValid;
			} else if ((tCompare >= 0) && (data[10].TreadDepth.length === 0 || data[10].TyrePsi.length === 0 || data[11].TreadDepth.length ===
					0 ||
					data[11].TyrePsi.length === 0 || data[12].TreadDepth.length === 0 || data[12].TyrePsi.length === 0 || data[13].TreadDepth.length ===
					0 || data[13].TyrePsi.length === 0 || data[14].TreadDepth.length === 0 || data[14].TyrePsi.length === 0 || data[15].TreadDepth.length ===
					0 || data[15].TyrePsi.length === 0)) {

				this.aMessage = {
					"text": "Please select Tanker Tire data using dropdown"
				};
				bValid = false
				return bValid;
			}
			return bValid;
		},
		validateTruckTyreData: function (data) {
			var bValid = true;
			if (data[0].TreadDepth.length === 0 || data[0].TyrePsi.length === 0 || data[1].TreadDepth.length === 0 || data[1].TyrePsi.length ===
				0 || data[2].TreadDepth.length === 0 || data[2].TyrePsi.length === 0 || data[3].TreadDepth.length === 0 || data[3].TyrePsi.length ===
				0 || data[4].TreadDepth.length === 0 || data[4].TyrePsi.length === 0 || data[5].TreadDepth.length === 0 || data[5].TyrePsi.length ===
				0 || data[6].TreadDepth.length === 0 || data[6].TyrePsi.length === 0 || data[7].TreadDepth.length === 0 || data[7].TyrePsi.length ===
				0 || data[8].TreadDepth.length === 0 || data[8].TyrePsi.length === 0 || data[9].TreadDepth.length === 0 || data[9].TyrePsi.length ===
				0) {
				this.aMessage = {
					"text": "Please select Truck tire data using dropdown"
				};
				bValid = false
				return bValid;
			}

			return bValid;
		},
		onDialogNextButton: function (oEvent) {
			this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === this._oSelectedStep.sId);
			var bValid = true;
			this.aMessage = {};
			var aTyreInspection = [];

			var oValidate = this.getView().getModel('data').getProperty('/bPageEditable');
			if (this._iSelectedStepIndex === 0) {
				if (oValidate === true) {
					if (this.getView().byId('iDInspType').getSelectedKey() === "") {
						MessageBox.warning('Please select Inspection type')
						return
					}

					if (this.getView().byId('idPlant').getSelectedKey() === "") {
						MessageBox.warning('Please select Plant')
						return
					}
					if (this.getView().byId('iDobjType').getSelectedKey() === "") {
						MessageBox.warning('Please select Object Type')
						return
					}
					if (this.getView().byId('idDriver').getValue() === "") {
						MessageBox.warning('Please select Driver')
						return
					}
					if (this.getView().byId('idTruckId').getValue() === "") {
						MessageBox.warning('Please select Truck')
						return
					}
					if (this.getView().byId('idTankId').getValue() === "" && this.getView().byId("idTankId").getVisible() === true) {
						MessageBox.warning('Please select Tanker')
						return
					}
				}
				//POST to create Notification
				//Get Default Model
				// this.oModel = this.getOwnerComponent().getModel();
				if (!this.sInp || (this.oStatus == "RFR" && oValidate === true)) {
					var that = this;
					this._oBusyDialog.open();
					var oEntry = {
						"InspType": this.byId("iDInspType").getSelectedKey(), //"Maintenance",  
						"Pequip": this.byId("idTruckId").getValue(), //this.getView().getModel('data').getProperty("/Pequip"), //"10000008",
						"Cequip": this.byId("idTankId").getValue(), //this.getView().getModel('data').getProperty("/Cequip"), //"TK-1041",
						// "OpWorkcenter": this.byId("iDWC").getSelectedKey(), //"RIY-TM",
						"ObjType": this.byId("iDobjType").getSelectedKey(), //"FLEET_BT",
						"SobjType": "",
						"InspNo": this.sInp,
						"Status": this.oStatus,
						"InspectorId": this.InspectorId, //this.byId("idInspId").getSelectedKey(),//"XINS0047",
						"InspectorName": this.InspectorName, //"Venkat",
						"Pplant": this.byId("idPlant").getSelectedKey(), //"4000",
						"CostCenter": this.getView().byId('idCC').getSelectedKey(),
						"Mplant": this.byId("idPlant").getSelectedKey(), //"4000",
						"DriverId": this.getView().getModel('data').getProperty("/DriverId"), //"XINS0047",
						"DriverName": this.getView().getModel('data').getProperty("/DriverName"), //"Venkat",
						"InspLoc": this.byId("idLoc").getSelectedKey(), //"RIY_MAINTN",
						"TruckMileage": this.byId("idTruckMil").getValue(), //"12"
					};
					var that = this;
					this.oModel.create("/ES_NotificationSet", oEntry, {
						method: "POST",
						success: function (oData) {
							that._oBusyDialog.close();
							if (oData.MessageType == "S") {
								sap.m.MessageBox.success(oData.Message + " " + "With" + " " + "Inspection Number " + oData.InspNo);
							} else {
								sap.m.MessageBox.error(oData.Message, {
									onClose: that.onClosePress()
								});
								// that.onClosePress();
							}
							that.getView().getModel('data').setProperty('/InspNo', oData.InspNo);
							that.getView().getModel('data').setProperty('/pNotif', oData.ParentNotif);
							that.getView().getModel('data').setProperty('/cNotif', oData.ChildNotif);

							// alert(JSON.stringify(oData));
						}.bind(this),
						error: function (oError) {
							that._oBusyDialog.close();
							sap.m.MessageBox.error(oError.message, {
								onClose: that.onClosePress()
							});
							// that.onClosePress();

							// sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						}
					});
				}
			}
			if (this._iSelectedStepIndex === 1) {
				this.aMessage = {};
				bValid = this.validateDocument();
				if (!bValid) {
					sap.m.MessageBox.error(this.aMessage.text);
					return;
				}

			}
			if (this._iSelectedStepIndex === 2) {
				//==========Validation truck  and Submit Operation====================
				this.aMessage = {};
				if (oValidate === true) {
					bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().truckinspections, "Truck");
					if (!bValid) {
						sap.m.MessageBox.error(this.aMessage.text);
						return;
					}
					bValid = this.validateTruckTyreData(this.getView().getModel('data').getData().tyreInspection, "Truck");
					if (!bValid) {
						sap.m.MessageBox.error(this.aMessage.text);
						return;
					}
				}
			}
			if (this._iSelectedStepIndex === 3) {
				//==========Validation  Tanker and Submit Operation====================
				if (oValidate === true) {
					this.aMessage = {};
					bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().tankerinspections, "Tanker");
					if (!bValid) {
						sap.m.MessageBox.error(this.aMessage.text);
						return;
					}
					this.aMessage = {};
					bValid = this.validateTankerTyreData(this.getView().getModel('data').getData().tyreInspection, "Tanker");
					if (!bValid) {
						sap.m.MessageBox.error(this.aMessage.text);
						return;
					}
				}
			}
			if (this._iSelectedStepIndex === 4) {
				//==========Validation truck and Tanke and Submit Operation====================
				var oPayload = {
					"InspId": this.getView().getModel('data').getProperty('/InspNo'),
					NAVCHLPOST: [],
					NAVTYRESDATA: []
				};
				this.aMessage = {};
				bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().tankerinspections, "Tanker");
				if (!bValid) {
					sap.m.MessageBox.error(this.aMessage.text);
					return;
				}
				this.aMessage = {};
				bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().truckinspections, "Truck");
				if (!bValid) {
					sap.m.MessageBox.error(this.aMessage.text);
					return;
				} else {
					aTyreInspection = this.getView().getModel('data').getProperty("/tyreInspection");
					aTyreInspection.forEach(function (objTyreInfo) {
						var objTyre = {
							Mandt: "",
							ObjectType: "",
							TyreNo: "",
							TreadDepth: "",
							TyrePsi: "",
							InspId: "",
							Iteration: "",
							ChecklistCat: ""
						}

						objTyre.ObjectType = objTyreInfo.ObjectType;
						objTyre.TyreNo = objTyreInfo.TyreNo;
						objTyre.TreadDepth = objTyreInfo.TreadDepth;
						objTyre.TyrePsi = objTyreInfo.TyrePsi;
						objTyre.InspId = objTyreInfo.InspId;
						objTyre.Iteration = objTyreInfo.Iteration;
						objTyre.ChecklistCat = objTyreInfo.ChecklistCat;
						oPayload.NAVTYRESDATA.push(objTyre);
					});

					// oPayload = this._createHeaderpayload(oPayload);
					var data = this.getView().getModel('data').getData();

					data.truckinspections.forEach(function (obj) {
						var obj1 = {};
						obj1.Taskcode = "";
						// obj.taskcode3=[];
						// obj.taskcode4=[];
						var chk1 = "0";
						var chk2 = "0";
						if (obj.taskcode3) {
							if (obj.taskcode3.length > 0) {
								chk1 = '1'
							}
						}
						if (obj.taskcode4) {
							if (obj.taskcode4.length > 0) {
								chk2 = '1'
							}
						}
						if (obj.taskcode1.length > 0 || obj.taskcode2.length > 0 || chk1 > 0 || chk2 > 0) {
							if (obj.taskcode1.length > 0) {
								obj.taskcode1.forEach(function (taskcod) {
									obj1.ChcklistCat = "01";
									// if (obj1.Taskcode == "") {
									obj1.Taskcode = taskcod;
									// } else {
									// obj1.Taskcode = obj1.Taskcode + "," + taskcod;
									// }
									obj1.ChecklistNo = obj.slno.toString();
									if (obj.pass == true) {
										obj1.Pass = 'X';
									} else {
										obj1.Pass = '';
									}
									obj1.Remarks = obj.remarks;
									obj1.ChecklistName = obj.description;
									obj1.GroupCode = obj.groupCode;
									obj1.GroupName = obj.groupName;
									obj1.TaskCodeType = "MECH";
									oPayload.NAVCHLPOST.push(obj1);
									obj1 = {};
								});
							}
							if (obj.taskcode2.length > 0) {
								obj.taskcode2.forEach(function (taskcod) {
									obj1.ChcklistCat = "01";
									obj1.Taskcode = taskcod;
									// if (obj1.Taskcode == "") {
									// 	obj1.Taskcode = taskcod;
									// } else {
									// 	obj1.Taskcode = obj1.Taskcode + "," + taskcod;
									// }
									obj1.ChecklistNo = obj.slno.toString();
									if (obj.pass == true) {
										obj1.Pass = 'X';
									} else {
										obj1.Pass = '';
									}
									obj1.ChecklistName = obj.description;
									obj1.Remarks = obj.remarks;
									obj1.GroupCode = obj.groupCode;
									obj1.GroupName = obj.groupName;
									obj1.TaskCodeType = "WELD";
									oPayload.NAVCHLPOST.push(obj1);
									obj1 = {};
								});
							}
							if (obj.taskcode3) {
								if (obj.taskcode3.length > 0) {
									obj.taskcode3.forEach(function (taskcod) {
										obj1.ChcklistCat = "01";
										obj1.Taskcode = taskcod;
										obj1.ChecklistNo = obj.slno.toString();
										if (obj.pass == true) {
											obj1.Pass = 'X';
										} else {
											obj1.Pass = '';
										}
										obj1.Remarks = obj.remarks;
										obj1.ChecklistName = obj.description;
										obj1.GroupCode = obj.groupCode;
										obj1.GroupName = obj.groupName;
										obj1.TaskCodeType = "ELEC";
										oPayload.NAVCHLPOST.push(obj1);
										obj1 = {};
									});
								}
							}
							if (obj.taskcode4) {
								if (obj.taskcode4.length > 0) {
									obj.taskcode4.forEach(function (taskcod) {
										obj1.ChcklistCat = "01";
										obj1.Taskcode = taskcod;
										obj1.ChecklistNo = obj.slno.toString();
										if (obj.pass == true) {
											obj1.Pass = 'X';
										} else {
											obj1.Pass = '';
										}
										obj1.Remarks = obj.remarks;
										obj1.ChecklistName = obj.description;
										obj1.GroupCode = obj.groupCode;
										obj1.GroupName = obj.groupName;
										obj1.TaskCodeType = "GAS";
										oPayload.NAVCHLPOST.push(obj1);
										obj1 = {};
									});
								}
							}
						} else {
							var obj1 = {};
							obj1.ChcklistCat = "01";
							obj1.ChecklistNo = obj.slno.toString();
							if (obj.pass == true) {
								obj1.Pass = 'X';
							} else {
								obj1.Pass = '';
							}
							obj1.Remarks = obj.remarks;
							obj1.Taskcode = "";
							obj1.ChecklistName = obj.description;
							obj1.GroupCode = obj.groupCode;
							obj1.GroupName = obj.groupName;
							obj1.TaskCodeType = obj.taskType;
							oPayload.NAVCHLPOST.push(obj1);
							obj1 = {};
						}
					});
					data.tankerinspections.forEach(function (obj) {
						var obj1 = {};
						obj1.Taskcode = "";
						var chk1 = "0";
						var chk2 = "0";
						if (obj.taskcode3) {
							if (obj.taskcode3.length > 0) {
								chk1 = '1'
							}
						}
						if (obj.taskcode4) {
							if (obj.taskcode4.length > 0) {
								chk2 = '1'
							}
						}
						if (obj.taskcode1.length > 0 || obj.taskcode2.length > 0 || chk1 > 0 || chk2 > 0) {
							// if (obj.taskcode1.length > 0 || obj.taskcode2.length > 0 || obj.taskcode3.length > 0 || obj.taskcode4.length > 0) {
							if (obj.taskcode1.length > 0) {
								obj.taskcode1.forEach(function (taskcod) {
									obj1.ChcklistCat = "02";
									obj1.Taskcode = taskcod;
									obj1.ChecklistNo = obj.slno.toString();
									if (obj.pass == true) {
										obj1.Pass = 'X';
									} else {
										obj1.Pass = '';
									}
									obj1.Remarks = obj.remarks;
									obj1.ChecklistName = obj.description;
									obj1.GroupCode = obj.groupCode;
									obj1.GroupName = obj.groupName;
									obj1.TaskCodeType = "MECH"
									oPayload.NAVCHLPOST.push(obj1);
									obj1 = {};
								});
							}
							if (obj.taskcode2.length > 0) {
								obj.taskcode2.forEach(function (taskcod) {
									obj1.ChcklistCat = "02";
									obj1.Taskcode = taskcod;
									obj1.ChecklistNo = obj.slno.toString();
									if (obj.pass == true) {
										obj1.Pass = 'X';
									} else {
										obj1.Pass = '';
									}
									obj1.ChecklistName = obj.description;
									obj1.Remarks = obj.remarks;
									obj1.GroupCode = obj.groupCode;
									obj1.GroupName = obj.groupName;
									obj1.TaskCodeType = "WELD"
									oPayload.NAVCHLPOST.push(obj1);
									obj1 = {};
								});
							}
							if (obj.taskcode3) {
								if (obj.taskcode3.length > 0) {
									obj.taskcode3.forEach(function (taskcod) {
										obj1.ChcklistCat = "02";
										obj1.Taskcode = taskcod;
										obj1.ChecklistNo = obj.slno.toString();
										if (obj.pass == true) {
											obj1.Pass = 'X';
										} else {
											obj1.Pass = '';
										}
										obj1.Remarks = obj.remarks;
										obj1.ChecklistName = obj.description;
										obj1.GroupCode = obj.groupCode;
										obj1.GroupName = obj.groupName;
										obj1.TaskCodeType = "ELEC"
										oPayload.NAVCHLPOST.push(obj1);
										obj1 = {};
									});
								}
							}
							if (obj.taskcode4) {
								if (obj.taskcode4.length > 0) {
									obj.taskcode4.forEach(function (taskcod) {
										obj1.ChcklistCat = "02";
										obj1.Taskcode = taskcod;
										obj1.ChecklistNo = obj.slno.toString();
										if (obj.pass == true) {
											obj1.Pass = 'X';
										} else {
											obj1.Pass = '';
										}
										obj1.Remarks = obj.remarks;
										obj1.ChecklistName = obj.description;
										obj1.GroupCode = obj.groupCode;
										obj1.GroupName = obj.groupName;
										obj1.TaskCodeType = "GAS";
										oPayload.NAVCHLPOST.push(obj1);
										obj1 = {};
									});
								}
							}
						} else {
							var obj1 = {};
							obj1.ChcklistCat = "02";
							obj1.ChecklistNo = obj.slno.toString();
							if (obj.pass == true) {
								obj1.Pass = 'X';
							} else {
								obj1.Pass = '';
							}
							obj1.Remarks = obj.remarks;
							obj1.Taskcode = "";
							obj1.ChecklistName = obj.description;
							obj1.GroupCode = obj.groupCode;
							obj1.GroupName = obj.groupName;
							obj1.TaskCodeType = obj.taskType;
							oPayload.NAVCHLPOST.push(obj1);
						}
					});

					data.documentinspections.forEach(function (obj) {

						var obj1 = {};
						obj1.ChcklistCat = "04";
						obj1.ChecklistNo = obj.slno.toString();
						if (obj.pass == true) {
							obj1.Pass = 'X';
						} else {
							obj1.Pass = '';
						}
						obj1.Remarks = obj.remarks;
						obj1.ChecklistName = obj.description;
						obj1.GroupCode = obj.groupCode;
						obj1.GroupName = obj.groupName;
						obj1.TaskCodeType = obj.taskType;
						oPayload.NAVCHLPOST.push(obj1);
					});
				}

				var that = this;
				that._oBusyDialog.open();

				this.oModel.create("/ET_Checklist_Hdr_PostSet", oPayload, {
					method: "POST",
					success: function (oData) {
						if (oData.Message.length > 0) {
							sap.m.MessageBox.success(oData.message);
						} else if (oData.PworkOrder.length > 0 || oData.CworkOrder.length > 0) {
							sap.m.MessageBox.success("Work Order(s) has been successfully created :" + oData.PworkOrder + "  " + oData.CworkOrder);
						} else {
							sap.m.MessageBox.success("Inspected successfully");
						}

						// Call Summary ES_INSP_SUMMARYSet?$filter=InspId eq '10000033'
						that.oModel.read("/ES_INSP_SUMMARYSet", {
							filters: [new sap.ui.model.Filter("InspId", "EQ", that.getView().getModel('data').getProperty('/InspNo'))],
							success: function (oData) {
								that.onEditablefields(false);
								that.getView().getModel('data').setProperty('/inspectionsummary', oData.results);
								that._oBusyDialog.close();
							}.bind(that),
							error: function (oError) {
								that._oBusyDialog.close();
								sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);

							}.bind(that),
						});
						that._oBusyDialog.close();
					}.bind(this),
					error: function (oError) {
						sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);

						that._oBusyDialog.close();
					}.bind(this),
				});
				//Call Summary ES_INSP_SUMMARYSet?$filter=InspId eq '10000033'

				this.oModel.read("/ES_INSP_SUMMARYSet", {
					filters: [new sap.ui.model.Filter("InspId", "EQ", that.getView().getModel('data').getProperty('/InspNo'))],
					success: function (oData) {
						that._oBusyDialog.close();
						that.getView().getModel('data').setProperty('/inspectionsummary', oData.results);
					}.bind(this),
					error: function (oError) {
						that._oBusyDialog.close();
						sap.m.MessageBox.error(JSON.parse(oError.responseText).error.message.value);
						that._oBusyDialog.close();
					}.bind(this),
				});
				//	}
			}
			// if (!bValid) {
			// 	MessageBox.warning('Please fill all the record');
			// 	return
			// }
			if (bValid) {

				// Display based on Selected Object Type
				var sSelectedKey = this.byId("iDobjType").getSelectedKey();
				switch (sSelectedKey) {
				case "FLEET_TK":
					// DO nothing
					break;
				case "FLEET_BT":
					if (this._iSelectedStepIndex === 0) {
						this._iSelectedStepIndex = 1;
					}
					// Escape Documentation
					break;
				case "FLEET_FK":
					// Only one step 
					if (this._iSelectedStepIndex === 0) {
						this._iSelectedStepIndex = 2;
					}
					break;
				case "FLEET_FB":
					//Escape Document
					if (this._iSelectedStepIndex === 0) {
						this._iSelectedStepIndex = 1;
					}
					break;
				case "FLEET_CR":
					// Only One Step
					if (this._iSelectedStepIndex === 0) {
						this._iSelectedStepIndex = 2;
					}
					break;
				default:
				}
				var oNextStep = this._oWizard.getSteps()[this._iSelectedStepIndex + 1];
				this._oWizard.setCurrentStep(oNextStep);
				this._oWizard.goToStep(oNextStep, true);
				this._iSelectedStepIndex++;
				this.handleVisibility();
				this._oSelectedStep = oNextStep;
			}

		},
		_createHeaderpayload: function (oPayload) {
			var oPayload = {
				InspId: "",
				Iteration: "",
				PEquipment: "",
				PlanPlant: "",
				CEquipment: "",
				InspType: "",
				MaintPlant: "",
				DriverName: this.getView().getModel('data').getProperty('/DriverName'),
				DriverId: this.getView().getModel('data').getProperty('/DriverId'),
				ObjectType: "",
				InspLoc: "",
				PNotif: "",
				CNotif: "",
				TruckMilage: "",
				PmdatePequi: "",
				SubObjectType: "",
				InspectorId: "",
				PmdateCequi: "",
				PworkOrder: "",
				CworkOrder: "",
				InspectorName: "",
				InspSdate: "",
				InspStime: "",
				InspEtime: "",
				InspEdate: "",
				OpWorkCenter: "",
				PnotifType: "",
				CnotifType: "",
				PwoType: "",
				CwoType: "",
				NAVCHLPOST: [],
				NAVTYRESDATA: []

			};
			return oPayload;
		},
		productTypeActivate: function () {
			// debugger
		},
		onAfterItemAdded: function (oEvent) {
			var item = oEvent.getParameter("item");
			var id = this.getView().getModel('data').getProperty('/InspNo');
			this._createEntity(item)
				.then((textStatus) => {
					if (textStatus === "success") {
						sap.m.MessageBox.success("File Uploaded Successfully");
					}
					this._uploadContent(item, id);
				})
				.catch((err) => {
					console.log(err);
				})
		},
		onUploadCompleted: function (oEvent) {
			var oUploadSet = this.byId("UploadSet1");
			oUploadSet.removeAllIncompleteItems();
			oUploadSet.getBinding("items").refresh();
		},
		onUploadCompleted2: function (oEvent) {
			var oUploadSet = this.byId("UploadSet2");
			oUploadSet.removeAllIncompleteItems();
			oUploadSet.getBinding("items").refresh();
		},
		_createEntity: function (item) {
			var data = {
				mediaType: item.getMediaType(),
				fileName: item.getFileName(),
				size: item.getFileObject().size
			};
			var chCat = "0" + item.getParent().sId.charAt(item.getParent().sId.length - 1);
			var oSlug = this.getView().getModel('data').getProperty('/InspNo') + "_" + chCat + "_" + data.fileName;
			var token = this.getView().getModel().getSecurityToken();
			var settings = {
				// url: "/sap/opu/odata/sap/ZOP_DTT_INSPECTION_APP_SRV/ES_MEDIA_DATA_POST",
				url: "/sap/opu/odata/sap/ZOP_DTT_INSPECTION_APP_SRV/ES_MEDIA_DATA",
				method: "POST",
				headers: {
					"Content-type": data.mediaType
				},
				data: JSON.stringify(data),
				beforeSend: function (xhr) {
					xhr.setRequestHeader("X-CSRF-Token", token);
					xhr.setRequestHeader("SLUG", oSlug);
				},
			}

			return new Promise((resolve, reject) => {
				$.ajax(settings)
					.done((results, textStatus, request) => {
						resolve(textStatus);
					})
					.fail((err) => {
						reject(err);
					})
			})
		},
		_uploadContent: function (item, id) {
			// var url = `/sap/opu/odata/sap/ZOP_DTT_INSPECTION_APP_SRV/ES_MEDIA_DATA_POST(${id})/content`
			var url = "/sap/opu/odata/sap/ZOP_DTT_INSPECTION_APP_SRV/ES_MEDIA_DATA(${id})/content";
			item.setUploadUrl(url);
			// var oUploadSet = this.byId("UploadSet1");
			var oUploadVehicle = item.getParent().sId.charAt(item.getParent().sId.length - 1);
			if (oUploadVehicle == "1") {
				var oUploadSet = this.byId("UploadSet1");
			} else if (oUploadVehicle == "2") {
				oUploadSet = this.byId("UploadSet2");
			}
			oUploadSet.setHttpRequestMethod("PUT")
			oUploadSet.uploadItem(item);
		},
		onThreadDept: function (oEvent) {
			if (oEvent.getSource().getCustomData()[0].getValue() == "0" || oEvent.getSource().getCustomData()[0].getValue() == "1") {
				if (oEvent.getSource().getSelectedKey() >= 4 && oEvent.getSource().getSelectedKey() <= 7) {
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}

			} else if (oEvent.getSource().getCustomData()[0].getValue() > "1" || oEvent.getSource().getCustomData()[0].getValue() <= "10") {
				if (oEvent.getSource().getSelectedKey() >= 4 && oEvent.getSource().getSelectedKey() <= 7) {
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
			} else {
				if (oEvent.getSource().getSelectedKey() >= 4) {
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
			}

		},
		onEditablefields: function (bFlag) {
			this.getView().getModel('data').setProperty('/bPageEditable', bFlag);
			var documentInspection = this.getView().getModel('data').getProperty('/documentinspections');
			documentInspection.forEach(function (obj) {
				obj.bPageEditable = bFlag;
			});
			var truckInspections = this.getView().getModel('data').getProperty('/truckinspections');
			truckInspections.forEach(function (obj) {
				obj.bPageEditable = bFlag;
			});
			var tyreInspection = this.getView().getModel('data').getProperty('/tyreInspection');
			tyreInspection.forEach(function (obj) {
				obj.bPageEditable = bFlag;
			});
			var tankerInspections = this.getView().getModel('data').getProperty('/tankerinspections');
			tankerInspections.forEach(function (obj) {
				obj.bPageEditable = bFlag;
			});

		},
		handleSelectionChange: function (oEvent) {
			var selectedObj = oEvent.getParameter('changedItem').getBindingContext('data').getObject();
			var selectedRow = oEvent.getSource().getBindingContext('data').getObject();
			selectedRow.groupCode = selectedObj.GROUP_CODE;
			selectedRow.groupName = selectedObj.GROUP_NAME;
			selectedRow.taskType = selectedObj.TASK_CODE_TYPE;
		},
		onObjectTypeSelect: function (oEvent) {
			var aData = this.getView().getModel('data').getProperty('/allData');
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			var aDocs = aData.documentinspections,
				aTruck = aData.truckinspections,
				aTanker = aData.tankerinspections;
			// var aDocs = aData['documentinspections' + sSelectedKey]
			// var aTruck = aData['truckinspections' + sSelectedKey]
			// var aTanker = aData['tankerinspections' + sSelectedKey]
			this.getView().byId("idTankId").setVisible(false);
			this.getView().byId("idTableDoc").setVisible(true);
			this.getView().byId("idFormDoc").setVisible(true);
			this.getView().byId("sMembershipOvpPageId").setVisible(true);
			this.getView().byId("idFormTruck").setVisible(true);

			switch (sSelectedKey) {
			case "FLEET_TK":
				this.getView().byId("idTankId").setVisible(true);
				this.getView().getModel('data').setProperty('/documentinspections', aDocs);
				this.getView().getModel('data').setProperty('/truckinspections', aTruck);
				this.getView().getModel('data').setProperty('/tankerinspections', aTanker);
				break;
			case "FLEET_BT":
				aTruck = aData.bTruckinspections;
				aTanker = aData.btankerinspections;
				this.getView().getModel('data').setProperty('/documentinspections', []);
				this.getView().getModel('data').setProperty('/truckinspections', aTruck);
				this.getView().getModel('data').setProperty('/tankerinspections', aTanker);
				this.getView().byId("idTableDoc").setVisible(false);
				this.getView().byId("idFormDoc").setVisible(false);
				this.getView().getModel('data').refresh();

				break;
			case "FLEET_FK":
				aTruck = aData.forkliftinspections;
				this.getView().getModel('data').setProperty('/documentinspections', []);
				this.getView().getModel('data').setProperty('/tankerinspections', aTruck);
				this.getView().getModel('data').setProperty('/truckinspections', []);

				this.getView().byId("idTableDoc").setVisible(false);
				this.getView().byId("idFormDoc").setVisible(false);
				this.getView().byId("sMembershipOvpPageId").setVisible(false);
				this.getView().byId("idFormTruck").setVisible(false);

				this.getView().getModel('data').refresh();

				break;
			case "FLEET_FB":
				aTruck = aData.flatTruckinspections;
				aTanker = aData.flabinspections;
				this.getView().getModel('data').setProperty('/documentinspections', []);
				this.getView().getModel('data').setProperty('/truckinspections', aTruck);
				this.getView().getModel('data').setProperty('/tankerinspections', aTanker);

				this.getView().byId("idTableDoc").setVisible(false);
				this.getView().byId("idFormDoc").setVisible(false);

				this.getView().getModel('data').refresh();

				break;
			case "FLEET_CR":
				aTruck = aData.isuzuinspections;
				this.getView().getModel('data').setProperty('/truckinspections', aTruck);
				this.getView().getModel('data').setProperty('/documentinspections', []);
				this.getView().getModel('data').setProperty('/tankerinspections', []);

				this.getView().byId("idTableDoc").setVisible(false);
				this.getView().byId("idFormDoc").setVisible(false);
				this.getView().byId("sMembershipOvpPageId").setVisible(false);
				this.getView().byId("idFormTruck").setVisible(false);

				this.getView().getModel('data').refresh();

				break;
			default:
			}

		},
		onEditPress: function () {
			this.getView().getModel("data").setProperty("/editVisible", false);
			this.getView().getModel("data").setProperty("/displyVisible", true);
			this.onEditablefields(true);
			if (this._iSelectedStepIndex === 4) {
				this.getView().getModel('data').setProperty('/submitVisible', true);
			}
		},
		onDisplayPress: function () {
			this.onEditablefields(false);
			this.getView().getModel("data").setProperty("/editVisible", true);
			this.getView().getModel("data").setProperty("/displyVisible", false);
			this.getView().getModel('data').setProperty('/submitVisible', false);
		},
		_oCreateNotifStepZero: function (oValidate) {
			var that = this;
			if (oValidate === true) {

				if (this.getView().byId('iDInspType').getSelectedKey() === "") {
					MessageBox.warning('Please select Inspection type')
					return
				}

				if (this.getView().byId('idPlant').getSelectedKey() === "") {
					MessageBox.warning('Please select Plant')
					return
				}
				if (this.getView().byId('iDobjType').getSelectedKey() === "") {
					MessageBox.warning('Please select Object Type')
					return
				}
				if (this.getView().byId('idDriver').getValue() === "") {
					MessageBox.warning('Please select Driver')
					return
				}
				if (this.getView().byId('idTruckId').getValue() === "") {
					MessageBox.warning('Please select Truck')
					return
				}
				if (this.getView().byId('idTankId').getValue() === "" && this.getView().byId("idTankId").getVisible() === true) {
					MessageBox.warning('Please select Tanker')
					return
				}
			}

			this._oBusyDialog.open();
			var oEntry = {
				"InspType": this.byId("iDInspType").getSelectedKey(), //"Maintenance",  
				"Pequip": this.byId("idTruckId").getValue(), //this.getView().getModel('data').getProperty("/Pequip"), //"10000008",
				"Cequip": this.byId("idTankId").getValue(), //this.getView().getModel('data').getProperty("/Cequip"), //"TK-1041",
				// "OpWorkcenter": this.byId("iDWC").getSelectedKey(), //"RIY-TM",
				"ObjType": this.byId("iDobjType").getSelectedKey(), //"FLEET_BT",
				"SobjType": "",
				"InspectorId": this.InspectorId, //this.byId("idInspId").getSelectedKey(),//"XINS0047",
				"InspectorName": this.InspectorName, //"Venkat",
				"Pplant": this.byId("idPlant").getSelectedKey(), //"4000",
				"CostCenter": this.getView().byId('idCC').getSelectedKey(),
				"Mplant": this.byId("idPlant").getSelectedKey(), //"4000",
				"DriverId": this.getView().getModel('data').getProperty("/DriverId"), //"XINS0047",
				"DriverName": this.getView().getModel('data').getProperty("/DriverName"), //"Venkat",
				"InspLoc": this.byId("idLoc").getSelectedKey(), //"RIY_MAINTN",
				"TruckMileage": this.byId("idTruckMil").getValue(), //"12"
			};
			var that = this;
			this.oModel.create("/ES_NotificationSet", oEntry, {
				method: "POST",
				success: function (oData) {
					that._oBusyDialog.close();
					if (oData.MessageType == "S") {
						sap.m.MessageBox.success(oData.Message + " " + "With" + " " + "Inspection Number " + oData.InspNo);
					} else {
						sap.m.MessageBox.error(oData.Message, {
							onClose: that.onClosePress()
						});
						// that.onClosePress();
					}
					that.getView().getModel('data').setProperty('/InspNo', oData.InspNo);
					that.getView().getModel('data').setProperty('/pNotif', oData.ParentNotif);
					that.getView().getModel('data').setProperty('/cNotif', oData.ChildNotif);

					// alert(JSON.stringify(oData));
				}.bind(this),
				error: function (oError) {
					that._oBusyDialog.close();
					sap.m.MessageBox.error(oError.message, {
						onClose: that.onClosePress()
					});

				}
			});
		},
		_oMessageConfirm: function (oParam) {
			if (this.oStatus == "RFR" && this._iSelectedStepIndex === 0) {
				var that = this;
				sap.m.MessageBox.confirm("New notifications will be created.Press YES to proceed!", {
					title: "Re-Inspection", // default
					onClose: function (oAction) {
						if (oAction === "YES") {
							// that.onEditablefields(true);
							that._oCreateNotifStepZero(oParam);
						}
					}, // default
					styleClass: "", // default
					actions: [sap.m.MessageBox.Action.YES,
						sap.m.MessageBox.Action.NO
					], // default
					emphasizedAction: sap.m.MessageBox.Action.YES, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
			}
		}

	});
});