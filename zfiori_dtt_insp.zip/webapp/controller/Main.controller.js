sap.ui.define([
"sap/ui/core/mvc/Controller",
"sap/ui/model/json/JSONModel",
"sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
"use strict";

return Controller.extend("com.gascozgasco.controller.Main", {
			onInit: function () {
				this.getInitLoad();
				this.getView().setModel(new JSONModel(), 'data')
				this.getView().getModel('data').setProperty('/previousEnabled', false)
				this.getView().getModel('data').setProperty('/nextEnabled', false)
				this.getView().getModel('data').setProperty('/submitVisible', false)
				this.getView().getModel('data').setProperty('/closeVisible', false)
				this.getView().getModel('data').setProperty('/continueEnabled', true)
				this.oResourceBundle = this.getOwnerComponent().getModel('i18n').getResourceBundle();
				this._oWizard = this.byId("CreateProductWizard");
				this._iSelectedStepIndex = 0;
				this.bValidated = true;
				this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex];
				//Set View Data
				this.setViewData();
				this._oWizard.attachModelContextChange((oEvent) => {
					// debugger
				});
				this._oWizard.attachValidationSuccess((oEvent) => {
					// debugger
				});

			},
			onPrint: function (oEvent) {
				var oTarget = this.getView();
				// var oTarget = this.getView().byId("dynamicPageId");
				var $domTarget = oTarget.$()[0],
					sTargetContent = $domTarget.innerHTML,
					sOriginalContent = document.body.innerHTML;

				document.body.innerHTML = sTargetContent;

				// var nameofWork =
				//     "A variable object is an abstract concept." + 
				//     "In different context types, physically, it’s presented" +
				//     " using different object. For example, in the global context" + 
				//     " the variable object is the global object itself (that’s why we have an ability to refer global variables via property names of the global object).";
				// var mainView = "<html><body><div><h2>Name of work:</h2><div><p>" + sTargetContent + "</p></div></div>";

				// mainView += "</body></html>";
				// var ctrlString = "width=900px,height=1200px";
				// sap.ui.core.BusyIndicator.hide();
				// var wind = window.open("", "PrintWindow", ctrlString);
				// wind.document.write(sTargetContent);
				// wind.print();
				// // wind.close();
				window.print();
				document.body.innerHTML = sOriginalContent;
			},
			onClosePress: function () {
				setTimeout(() => {
					// this._oWizard.setCurrentStep(this._oWizard.getSteps()[2]);
					// this._oWizard.setCurrentStep(this._oWizard.getSteps()[0]);
					this._oWizard.goToStep(this._oWizard.getSteps()[this._iSelectedStepIndex]);
					this.getView().setBusy(false)
					this.bValidated = true;
					this.setViewData();
				}, 2000)
				this.getView().setBusy(true)

				// this._oWizard.setCurrentStep(this._oWizard.getSteps()[1]);
				this._oWizard.setCurrentStep(this._oWizard.getSteps()[0]);
				// this.onDialogNextButton();
				// this.onDialogBackButton();

				this._iSelectedStepIndex = 0;
				this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex]

				this.handleVisibility();
			},
			handleNavigationChange: function (oEvent) {
				// this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === oEvent.getParameter('step').sId)
				// this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex]
				// this.handleVisibility();
			},
			setViewData: function () {
				var oData = {
					documentinspections: [{
						slno: 1,
						description: this.oResourceBundle.getText('extExamination'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 2,
						description: this.oResourceBundle.getText('hydrostatic'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 3,
						description: this.oResourceBundle.getText('internalcertificate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 4,
						description: this.oResourceBundle.getText('thicknesscertificate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 5,
						description: this.oResourceBundle.getText('preventivecertificate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 6,
						description: this.oResourceBundle.getText('periodiccertificate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 7,
						description: this.oResourceBundle.getText('drivinflicense'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 8,
						description: this.oResourceBundle.getText('professionaldriver'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 9,
						description: this.oResourceBundle.getText('registrationcertificate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 10,
						description: this.oResourceBundle.getText('iqama'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 11,
						description: this.oResourceBundle.getText('aramcocard'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 12,
						description: this.oResourceBundle.getText('gascocard'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 13,
						description: this.oResourceBundle.getText('vehicledrivercard'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 14,
						description: this.oResourceBundle.getText('insurancecard'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 15,
						description: this.oResourceBundle.getText('inspectionplate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 16,
						description: this.oResourceBundle.getText('sasoplate'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}, {
						slno: 17,
						description: this.oResourceBundle.getText('contactnumbers'),
						bEditable: false,
						pass: false,
						fail: false,
						remarks: ''
					}],
					truckinspections: [{
						slno: 1,
						description: this.oResourceBundle.getText('title1'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 2,
						description: this.oResourceBundle.getText('title2'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 3,
						description: this.oResourceBundle.getText('title3'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 4,
						description: this.oResourceBundle.getText('title4'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 5,
						description: this.oResourceBundle.getText('title5'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 6,
						description: this.oResourceBundle.getText('title6'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 7,
						description: this.oResourceBundle.getText('title7'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 8,
						description: this.oResourceBundle.getText('title8'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 9,
						description: this.oResourceBundle.getText('title9'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 10,
						description: this.oResourceBundle.getText('title10'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 11,
						description: this.oResourceBundle.getText('title11'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 12,
						description: this.oResourceBundle.getText('title12'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 13,
						description: this.oResourceBundle.getText('title13'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 14,
						description: this.oResourceBundle.getText('title14'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 15,
						description: this.oResourceBundle.getText('title15'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}],
					tankerinspections: [{
						slno: 1,
						description: this.oResourceBundle.getText('tankertitle1'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 2,
						description: this.oResourceBundle.getText('tankertitle2'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 3,
						description: this.oResourceBundle.getText('tankertitle3'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 4,
						description: this.oResourceBundle.getText('tankertitle4'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 5,
						description: this.oResourceBundle.getText('tankertitle5'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 6,
						description: this.oResourceBundle.getText('tankertitle6'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 7,
						description: this.oResourceBundle.getText('tankertitle7'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 8,
						description: this.oResourceBundle.getText('tankertitle8'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 9,
						description: this.oResourceBundle.getText('tankertitle9'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 10,
						description: this.oResourceBundle.getText('tankertitle10'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 11,
						description: this.oResourceBundle.getText('tankertitle11'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 12,
						description: this.oResourceBundle.getText('tankertitle12'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 13,
						description: this.oResourceBundle.getText('tankertitle13'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 14,
						description: this.oResourceBundle.getText('tankertitle14'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 15,
						description: this.oResourceBundle.getText('tankertitle15'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 16,
						description: this.oResourceBundle.getText('tankertitle16'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}, {
						slno: 17,
						description: this.oResourceBundle.getText('tankertitle17'),
						bEditable: false,
						pass: false,
						fail: false,
						taskcode1: [],
						taskcode2: [],
						countcode: [],
						failcode: [],
						remarks: ''
					}],
					items: [{
						description: 'Item1',
						key: '1'
					}, {
						description: 'Item2',
						key: '2'
					}, {
						description: 'Item3',
						key: '3'
					}, {
						description: 'Item4',
						key: '4'
					}],
					valueitems: [{
						value: 'Item1',
						key: '1'
					}, {
						value: 'Item2',
						key: '2'
					}, {
						value: 'Item3',
						key: '3'
					}, {
						value: 'Item4',
						key: '4'
					}],
					subobjects: [{
						value: 'Item1',
						key: '1'
					}, {
						description: 'Item2',
						key: '2'
					}, {
						description: 'Item3',
						key: '3'
					}],
					inspectionsummary: [{
						createdBy: 'Paulwin Thekkekkara',
						createdDate: '12-Feb-2023',
						createdTime: '12:20',
						endDate: '12-Feb-2023',
						endTime: '12:20',
						reprocesscount: '0',
						totprocesstime: '2',
						approvedBy: ''
					}, {
						createdBy: 'Paulwin Thekkekkara',
						createdDate: '12-Feb-2023',
						createdTime: '12:20',
						endDate: '12-Feb-2023',
						endTime: '12:20',
						reprocesscount: '1',
						totprocesstime: '12',
						approvedBy: 'Sam'
					}, {
						createdBy: 'Paulwin Thekkekkara',
						createdDate: '12-Feb-2023',
						createdTime: '12:20',
						endDate: '12-Feb-2023',
						endTime: '12:20',
						reprocesscount: '2',
						totprocesstime: '42',
						approvedBy: 'Sam'
					}]
				};
				debugger;
				this.getView().getModel('data').setProperty('/inspectionsummary', oData.inspectionsummary);
				this.getView().getModel('data').setProperty('/subobjects', oData.subobjects);
				this.getView().getModel('data').setProperty('/valueitems', oData.valueitems);
				this.getView().getModel('data').setProperty('/documentinspections', oData.documentinspections);
				this.getView().getModel('data').setProperty('/truckinspections', oData.truckinspections);
				this.getView().getModel('data').setProperty('/tankerinspections', oData.tankerinspections);
				this.getView().getModel('data').setProperty('/items', oData.valueitems);

				this.getView().getModel('data').setProperty('/docpass', 0);
				this.getView().getModel('data').setProperty('/docfail', 0);
				this.getView().getModel('data').setProperty('/truckpass', 0);
				this.getView().getModel('data').setProperty('/truckfail', 0);
				this.getView().getModel('data').setProperty('/tankerpass', 0);
				this.getView().getModel('data').setProperty('/tankerfail', 0);
				this.getView().getModel('data').setProperty('/allData', oData);
				// this.getView().byId('SSubObjId').setSelectedKey("")
				this.getView().getModel('data').setProperty('/preventivesch', new Date());
				this.getView().getModel('data').setProperty('/trprvntsch', new Date());
			},
			getInitLoad: function () {
				//Get Default Model
				this.oModel = this.getOwnerComponent().getModel();
				var that = this;
				var k = [];
				//Get Dropdown Data
				//Read Dropdown values 
				this.oModel.read("/ES_F4_INITSet", {
					filters: [new sap.ui.model.Filter("F4Id", "EQ", "INIT")],
					urlParameters: {
						$expand: "NAVINSPLOC,NAVINSPTYPE,NAVOBJTYPE,NAVPLANT,NAVTASKCODES,NAVOPWCNTR"
					},
					success: function (oData) {
						debugger;
						oData.results.forEach(function (element, i) {
							//Inspector ID & Name

							that.InspectorId = element.InspId;
							that.InspectorName = element.InspName;
							that.getView().getModel('data').setProperty('/inspID', that.InspectorId);
							that.getView().getModel('data').setProperty('/inspName', that.InspectorName);
							// 		
							//Inspection Location
							if (element.NAVINSPLOC.results.length > 0) {
								that.getView().getModel('data').setProperty('/InspLoc', element.NAVINSPLOC.results);
							}
							// Inspection Type
							if (element.NAVINSPTYPE.results.length > 0) {
								that.getView().getModel('data').setProperty('/InspType', element.NAVINSPTYPE.results);
							}
							// Object Type
							if (element.NAVOBJTYPE.results.length > 0) {
								that.getView().getModel('data').setProperty('/ObjType', element.NAVOBJTYPE.results);
							}
							// Plant
							if (element.NAVPLANT.results.length > 0) {
								that.getView().getModel('data').setProperty('/Plant', element.NAVPLANT.results);
							}
							//  Task Codes
							if (element.NAVTASKCODES.results.length > 0) {
								element.NAVTASKCODES.results.forEach(function (e, i) {
									switch (e.TASK_CODE_TYPE) {
									case "MECHANICAL TASKS":
										if (!that.tCode1) {
											that.tCode1 = [];
										}
										that.tCode1.push({
											TASK_CODE: e.TASK_CODE,
											TASK_DESCR: e.TASK_DESCR
										})
										break;
									case "":
										if (!that.countcode) {
											that.tCode2 = [];
										}
										that.tCode2.push({
											TASK_CODE: e.TASK_CODE,
											TASK_DESCR: e.TASK_DESCR
										})
										break;
									case "":
										if (!that.tCode3) {
											that.tCode3 = [];
										}
										that.tCode3.push({
											TASK_CODE: e.TASK_CODE,
											TASK_DESCR: e.TASK_DESCR
										})
										break;
									case "":
										if (!that.tCode4) {
											that.tCode4 = [];
										}
										that.tCode4.push({
											TASK_CODE: e.TASK_CODE,
											TASK_DESCR: e.TASK_DESCR
										})
										break;
									default:
									}
								})
								that.getView().getModel('data').setProperty('/TaskCode1', that.tCode1);
								that.getView().getModel('data').setProperty('/TaskCode2', that.tCode2);
								that.getView().getModel('data').setProperty('/TaskCode3', that.tCode3);
								that.getView().getModel('data').setProperty('/TaskCode4', that.tCode4);
							}
							// Work Center
							if (element.NAVOPWCNTR.results.length > 0) {
								that.getView().getModel('data').setProperty('/WorkCenter', element.NAVOPWCNTR.results);
							}
						})
					}.bind(this),
					error: function (oError) {}
				});
			},
			onValueHelpDriver: function (oEvent) {
				//Check Plant for ValueHelp

				if (this._Driver) {
					this._Driver.destroy();
					this._Driver = null;
				}
				var oView = this.getView();
				if (!this._Driver) {
					this._Driver = sap.ui.xmlfragment("driver", "com.apple.ui5.ZUI5_AC_SHIPMENT.fragment.driver", this);
					oView.addDependent(this._Driver);
					this._Driver.setRangeKeyFields([{
						label: "Ship-To Partner",
						key: "Driver",
						type: "String",
						typeInstance: new typeString({}, {
							maxLength: 25
						})
					}]);
				}

			},
			onValueHelpDriverOkPress: function (oEvent) {},
			onValueHelpDriverCancelPress: function (oEvent) {},
			onValueHelpAfterClose: function (oEvent) {},
			onObjectTypeSelect: function (oEvent) {
				debugger
				var aData = this.getView().getModel('data').getProperty('/allData')
				var sSelectedKey = oEvent.getSource().getSelectedKey(),
					aDocs = aData.documentinspections,
					aTruck = aData.truckinspections,
					aTanker = aData.tankerinspections;
				// var aDocs = aData['documentinspections' + sSelectedKey]
				// var aTruck = aData['truckinspections' + sSelectedKey]
				// var aTanker = aData['tankerinspections' + sSelectedKey]
				this.getView().getModel('data').setProperty('/documentinspections', aDocs);
				this.getView().getModel('data').setProperty('/truckinspections', aTruck);
				this.getView().getModel('data').setProperty('/tankerinspections', aTanker);
				// var sSelectedKey = oEvent.getSource().getSelectedKey();
				// var aList = [];
				// for (var i = 0; i < parseInt(sSelectedKey); i++) {
				// 	aList.push({
				// 		description: 'Item' + i,
				// 		key: i + ''
				// 	})
				// }
				// this.getView().getModel('data').setProperty('/items', aList);
			},
			handleCount: function (aData, passcount, failcount) {
				var nPass = 0;
				var nFail = 0;
				aData.forEach((oItem) => {
					if (oItem.pass) {
						nPass += 1;
					}
					if (oItem.fail) {
						nFail += 1;
					}
				})
				this.getView().getModel('data').setProperty(passcount, nPass);
				this.getView().getModel('data').setProperty(failcount, nFail);
			},
			onDocumentInspectionCheckSelect: function (oEvent) {
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/docpass', '/docfail');
				if (oSelectedObject.pass) {
					oSelectedObject.pass = false
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}
				if (!oSelectedObject.fail) {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				} else {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
				}
			},
			onDialogBackButton: function () {
				this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === this._oSelectedStep.sId)
				var oPreviousStep = this._oWizard.getSteps()[this._iSelectedStepIndex - 1];
				// this._oWizard.previousStep();
				// if (this._oSelectedStep) {
				this._oWizard.goToStep(oPreviousStep, true);
				// } else {
				// 	this._oWizard.previousStep();
				// }

				this._iSelectedStepIndex--;
				this.handleVisibility();
				this._oSelectedStep = oPreviousStep;

				// this.handleButtonsVisibility();
			},
			handleVisibility: function () {
				if (this._iSelectedStepIndex === 0) {
					this.getView().getModel('data').setProperty('/previousEnabled', false)
					this.getView().getModel('data').setProperty('/nextEnabled', false)
					this.getView().getModel('data').setProperty('/submitVisible', false)
					this.getView().getModel('data').setProperty('/continueEnabled', true)
				} else {
					this.getView().getModel('data').setProperty('/previousEnabled', true)
					this.getView().getModel('data').setProperty('/nextEnabled', true)
					this.getView().getModel('data').setProperty('/continueEnabled', false)
				}
				if (this._iSelectedStepIndex === 4) {
					this.getView().getModel('data').setProperty('/previousEnabled', false)
					this.getView().getModel('data').setProperty('/submitVisible', false)
					this.getView().getModel('data').setProperty('/nextEnabled', false)
					this.getView().getModel('data').setProperty('/closeVisible', true)
					this.getView().getModel('data').setProperty('/continueEnabled', false)
				} else {
					this.getView().getModel('data').setProperty('/closeVisible', false)
				}
				if (this._iSelectedStepIndex === 3) {
					this.getView().getModel('data').setProperty('/submitVisible', true)
					this.getView().getModel('data').setProperty('/nextEnabled', false)
				} else if (this._iSelectedStepIndex > 0 && this._iSelectedStepIndex < 3) {
					this.getView().getModel('data').setProperty('/submitVisible', false)
					this.getView().getModel('data').setProperty('/nextEnabled', true)
				}
			},
			onTruckInspectionPassCheckSelect: function (oEvent) {
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/truckpass', '/truckfail');
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				if (oSelectedObject.fail) {
					oSelectedObject.fail = false;
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}

				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode1', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode2', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/countcode', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/failcode', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
			},
			onTruckInspectionCheckSelect: function (oEvent) {
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/truckpass', '/truckfail');
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				if (oSelectedObject.pass) {
					oSelectedObject.pass = false
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}
				if (oSelectedObject.fail) {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
				} else {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				}
			},
			onTankerInspectionCheckSelect: function (oEvent) {
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/tankerpass', '/tankerfail');
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				if (oSelectedObject.pass) {
					oSelectedObject.pass = false
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}
				if (oSelectedObject.fail) {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", true)
				} else {
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
				}
			},
			onTankerInspectionPassCheckSelect: function (oEvent) {
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/tankerpass', '/tankerfail');
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				if (oSelectedObject.fail) {
					oSelectedObject.fail = false;
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode1', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/taskcode2', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/countcode', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/failcode', [])
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
			},
			onDocumentInspectionPassCheckSelect: function (oEvent) {
				var aData = oEvent.getSource().getBindingContext('data').getProperty('/' + oEvent.getSource().getBindingContext('data').getPath()
					.split(
						'/')[1]);
				this.handleCount(aData, '/docpass', '/docfail');
				var oSelectedObject = this.getView().getModel('data').getProperty(oEvent.getSource().getBindingContext('data').getPath());
				if (oSelectedObject.fail) {
					oSelectedObject.fail = false;
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + "/bEditable", false)
					this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath(), oSelectedObject)
				}
				this.getView().getModel('data').setProperty(oEvent.getSource().getBindingContext('data').getPath() + '/remarks', '')
			},
			validateDocument: function () {
				var aData = this.getView().getModel('data').getData()
				var bValid = true;
				aData.documentinspections.forEach((oItem) => {
					if (oItem.fail) {
						if (oItem.remarks === '') {
							bValid = false
						}
					}
				})
				return bValid;
			},
			validateTruckandTanker: function (aData) {
				var bValid = true;
				aData.forEach((oItem) => {
					if (oItem.fail) {
						if (oItem.remarks === '' || oItem.failcode.length === 0 || oItem.countcode.length === 0 || oItem.taskcode1.length === 0 ||
							oItem.taskcode2.length === 0) {
							bValid = false
						}
					}
				})
				return bValid;
			},
			onDialogNextButton: function (oEvent) {
				debugger;
				this._iSelectedStepIndex = this._oWizard.getSteps().findIndex(i => i.sId === this._oSelectedStep.sId);
				var bValid = true;
				if (this._iSelectedStepIndex === 0) {
					// if (this.getView().byId('SSubObjId').getSelectedKey() === "") {
					// 	MessageBox.warning('Please select Subobject type')
					// 	return
					// }
					//POST to create Notification
					//Get Default Model
					// this.oModel = this.getOwnerComponent().getModel();
					var that = this;
					var oEntry = {
						"InspType": "Maintenance",
						"Pequip": "10000008",
						"Cequip": "TK-1041",
						"OpWorkcenter": "RIY-TM",
						"ObjType": "FLEET_BT",
						"SobjType": "",
						"InspectorId": "XINS0047",
						"InspectorName": "Venkat",
						"Pplant": "4000",
						"Mplant": "4000",
						"DriverId": "XINS0047",
						"DriverName": "Venkat",
						"InspLoc": "RIY_MAINTN",
						"TruckMileage": "12"
					};

					this.oModel.create("/ES_NotificationSet", oEntry, {
								method: "POST",
								success: function (oData) {
									debugger;
									alert(JSON.stringify(oData));
						}.bind(this),
						error: function (oError) {}
				});
				}
		if (this._iSelectedStepIndex === 1) {
			bValid = this.validateDocument();
		}
		if (this._iSelectedStepIndex === 2) {
			bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().truckinspections);
		}
		if (this._iSelectedStepIndex === 3) {
			bValid = this.validateTruckandTanker(this.getView().getModel('data').getData().tankerinspections);
		}
		if (!bValid) {
			MessageBox.warning('Please fill all the record');
			return
		}
		var oNextStep = this._oWizard.getSteps()[this._iSelectedStepIndex + 1]; 
		this._oWizard.setCurrentStep(oNextStep);
		// this._oWizard.nextStep();
		// 
		// if (this._oSelectedStep && !this._oSelectedStep.bLast) {
		// if (oNextStep.bOutput) {
		this._oWizard.goToStep(oNextStep, true);
		// } else {
		// 	this._oWizard.nextStep();
		// }

		// } else {
		// 	this._oWizard.nextStep();
		// }

		this._iSelectedStepIndex++; this.handleVisibility(); this._oSelectedStep = oNextStep;

		// this.handleButtonsVisibility();
	},
	productTypeActivate: function () {
		// debugger
	}

});
});